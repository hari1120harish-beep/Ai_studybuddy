import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Sparkles,
  Send,
  BookOpen,
  HelpCircle,
  Lightbulb,
  Copy,
  Check,
  RotateCcw,
} from 'lucide-react';
import { StudyMaterial } from '../types';
import { api } from '../services/api';

interface AITutorViewProps {
  initialMaterialId?: string | null;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  followUpQuestions?: string[];
  suggestedResources?: string[];
  timestamp: string;
}

export const AITutorView: React.FC<AITutorViewProps> = ({ initialMaterialId }) => {
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>(initialMaterialId || '');
  const [mode, setMode] = useState<'explain' | 'analogy' | 'practice_problem' | 'deep_dive'>('explain');
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg_welcome',
      role: 'assistant',
      content:
        'Hello! I am your AI StudyBuddy tutor. Ask me any question about your course materials, request a step-by-step concept breakdown, get real-world analogies, or practice solving problems.',
      followUpQuestions: [
        'Can you explain Backpropagation using an intuitive analogy?',
        'How does Virtual Memory Paging prevent fragmentation in OS?',
        'Give me a challenging practice problem on Loss Functions.',
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  useEffect(() => {
    api.getMaterials().then((res) => setMaterials(res.materials || []));
  }, []);

  useEffect(() => {
    if (initialMaterialId) {
      setSelectedMaterialId(initialMaterialId);
    }
  }, [initialMaterialId]);

  const handleSendMessage = async (queryToSend?: string) => {
    const text = (queryToSend || inputQuery).trim();
    if (!text || loading) return;

    const userMsg: Message = {
      id: `msg_${Date.now()}_u`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await api.askTutor({
        question: text,
        materialId: selectedMaterialId || undefined,
        mode,
      });

      const assistantMsg: Message = {
        id: `msg_${Date.now()}_a`,
        role: 'assistant',
        content: res.answer,
        followUpQuestions: res.followUpQuestions,
        suggestedResources: res.suggestedResources,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      const errorMsg: Message = {
        id: `msg_${Date.now()}_err`,
        role: 'assistant',
        content: `Error: ${err.message || 'Unable to generate explanation. Please try again.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">AI StudyBuddy Tutor</h2>
        <p className="text-xs text-slate-500">
          Interactive pedagogical assistant grounded in your uploaded course materials.
        </p>
      </div>

      {/* Control Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200 bg-white shadow-xs">
        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-indigo-600" />
          <span className="text-xs font-semibold text-slate-700">Context Source:</span>
          <select
            value={selectedMaterialId}
            onChange={(e) => setSelectedMaterialId(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 max-w-xs truncate"
          >
            <option value="">All Uploaded Study Materials</option>
            {materials.map((m) => (
              <option key={m.id} value={m.id}>
                {m.title} ({m.category})
              </option>
            ))}
          </select>
        </div>

        {/* Learning Mode Selector */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setMode('explain')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
              mode === 'explain' ? 'bg-white text-indigo-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Step-by-Step
          </button>
          <button
            onClick={() => setMode('analogy')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
              mode === 'analogy' ? 'bg-white text-indigo-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Analogy
          </button>
          <button
            onClick={() => setMode('practice_problem')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
              mode === 'practice_problem' ? 'bg-white text-indigo-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Practice Problem
          </button>
          <button
            onClick={() => setMode('deep_dive')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
              mode === 'deep_dive' ? 'bg-white text-indigo-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Deep Dive
          </button>
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden flex flex-col h-[65vh]">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
                  <Sparkles className="h-4 w-4" />
                </div>
              )}

              <div
                className={`max-w-2xl rounded-2xl p-4 text-xs sm:text-sm leading-relaxed shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-slate-50 border border-slate-100 text-slate-800 rounded-tl-none whitespace-pre-line'
                }`}
              >
                <div>{msg.content}</div>

                {/* Follow up prompt chips */}
                {msg.followUpQuestions && msg.followUpQuestions.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-200/60 space-y-1.5">
                    <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Suggested follow-ups:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.followUpQuestions.map((q, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(q)}
                          className="text-left text-xs px-2.5 py-1 rounded-md bg-white border border-slate-200 text-indigo-700 hover:bg-indigo-50 font-medium transition-colors"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div
                  className={`mt-1.5 text-[10px] ${
                    msg.role === 'user' ? 'text-indigo-200 text-right' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white">
                <Sparkles className="h-4 w-4 animate-spin" />
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-500">
                StudyBuddy is formulating explanation with Gemini 3.8 Flash...
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-slate-200 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask anything about your notes, request analogies, or practice questions..."
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <button
              type="submit"
              disabled={loading || !inputQuery.trim()}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-40 transition-colors shadow-xs"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
