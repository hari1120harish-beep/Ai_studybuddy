import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Copy,
  Check,
  Download,
  Trash2,
  ChevronDown,
  ChevronUp,
  Brain,
  ListChecks,
  Network,
  HelpCircle,
  BookOpen,
} from 'lucide-react';
import { Summary, StudyMaterial } from '../types';
import { api } from '../services/api';

interface SummariesViewProps {
  initialMaterial?: StudyMaterial | null;
}

export const SummariesView: React.FC<SummariesViewProps> = ({ initialMaterial }) => {
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [selectedSummary, setSelectedSummary] = useState<Summary | null>(null);
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);

  // Generator form
  const [selectedMatId, setSelectedMatId] = useState<string>(initialMaterial?.id || '');
  const [customText, setCustomText] = useState<string>('');
  const [summaryTitle, setSummaryTitle] = useState<string>(initialMaterial?.title || '');
  const [mode, setMode] = useState<'brief' | 'comprehensive' | 'key-points' | 'exam-prep'>('comprehensive');
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  // Audio Speech state
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);

  // Accordion for self-test questions
  const [revealedQuestions, setRevealedQuestions] = useState<Record<number, boolean>>({});

  const loadData = async () => {
    try {
      setLoading(true);
      const [sumRes, matRes] = await Promise.all([
        api.getSummaries(),
        api.getMaterials(),
      ]);
      setSummaries(sumRes.summaries || []);
      setMaterials(matRes.materials || []);

      if (sumRes.summaries && sumRes.summaries.length > 0 && !selectedSummary) {
        setSelectedSummary(sumRes.summaries[0]);
      }
    } catch (err) {
      console.error('Failed to load summaries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (initialMaterial) {
      setSelectedMatId(initialMaterial.id);
      setSummaryTitle(initialMaterial.title);
    }
  }, [initialMaterial]);

  // Audio Speech controls
  const handleToggleAudio = () => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in this browser.');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    if (!selectedSummary) return;

    window.speechSynthesis.cancel(); // reset any ongoing
    const textToSpeak = `${selectedSummary.title}. Executive summary: ${selectedSummary.executiveSummary}. Key takeaways: ${selectedSummary.takeaways.join('. ')}`;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = speechRate;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.speak(utterance);
    setIsPlayingAudio(true);
  };

  const handleStopAudio = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    handleStopAudio();

    try {
      let content = customText;
      let title = summaryTitle;
      let category = 'General';

      if (selectedMatId) {
        const mat = materials.find((m) => m.id === selectedMatId);
        if (mat) {
          content = mat.content;
          title = summaryTitle || mat.title;
          category = mat.category;
        }
      }

      const res = await api.generateSummary({
        materialId: selectedMatId || undefined,
        title: title || 'Study Summary',
        category,
        mode,
        content: content || undefined,
      });

      setSummaries((prev) => [res.summary, ...prev]);
      setSelectedSummary(res.summary);
      setCustomText('');
    } catch (err: any) {
      alert(err.message || 'Failed to generate summary.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this summary?')) return;
    try {
      await api.deleteSummary(id);
      const remaining = summaries.filter((s) => s.id !== id);
      setSummaries(remaining);
      if (selectedSummary?.id === id) {
        setSelectedSummary(remaining[0] || null);
      }
    } catch (err) {
      alert('Failed to delete summary.');
    }
  };

  const handleCopy = () => {
    if (!selectedSummary) return;
    const text = `# ${selectedSummary.title}\n\n## Executive Summary\n${selectedSummary.executiveSummary}\n\n## Key Concepts\n${selectedSummary.keyConcepts.map((k) => `- **${k.term}**: ${k.explanation}`).join('\n')}\n\n## Takeaways\n${selectedSummary.takeaways.map((t) => `- ${t}`).join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">AI Study Summaries</h2>
        <p className="text-xs text-slate-500">
          Synthesize complex study materials into structured executive briefs, conceptual breakdowns, and mindmaps.
        </p>
      </div>

      {/* Generator Drawer / Card */}
      <div className="rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50/50 via-white to-slate-50 p-5 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white">
            <Sparkles className="h-4 w-4" />
          </div>
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Generate New Summary with Gemini AI
          </h3>
        </div>

        <form onSubmit={handleGenerate} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Choose Source Material */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Select Source Material
              </label>
              <select
                value={selectedMatId}
                onChange={(e) => {
                  setSelectedMatId(e.target.value);
                  const mat = materials.find((m) => m.id === e.target.value);
                  if (mat) setSummaryTitle(mat.title);
                }}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="">-- Or paste text below --</option>
                {materials.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title} ({m.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Custom Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Summary Title
              </label>
              <input
                type="text"
                value={summaryTitle}
                onChange={(e) => setSummaryTitle(e.target.value)}
                placeholder="e.g. Operating Systems Paging Synthesis"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Summary Mode */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Summary Mode
              </label>
              <select
                value={mode}
                onChange={(e) => setMode(e.target.value as any)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="comprehensive">Comprehensive (In-depth + Mindmap)</option>
                <option value="brief">Executive Brief (Quick recap)</option>
                <option value="key-points">Key Concepts & Vocabulary Only</option>
                <option value="exam-prep">Exam-Prep (High-Yield Focus)</option>
              </select>
            </div>
          </div>

          {!selectedMatId && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Or Paste Study Notes / Article Text Directly:
              </label>
              <textarea
                rows={3}
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder="Paste paragraph or excerpt to summarize immediately..."
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
              />
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={generating || (!selectedMatId && !customText.trim())}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs disabled:opacity-50 transition-colors"
            >
              {generating ? (
                <>
                  <div className="h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing with Gemini 3.8 Flash...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Generate Summary</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Main Split: Summaries Library Sidebar & Active Summary View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Sidebar: Library */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Saved Summaries ({summaries.length})
            </h3>
          </div>

          <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
            {summaries.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-xs text-slate-400">
                No summaries yet. Generate your first one above!
              </div>
            ) : (
              summaries.map((s) => (
                <div
                  key={s.id}
                  onClick={() => {
                    handleStopAudio();
                    setSelectedSummary(s);
                  }}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    selectedSummary?.id === s.id
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <span className="text-[10px] font-bold uppercase text-indigo-600">
                      {s.category}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(s.id);
                      }}
                      className="text-slate-300 hover:text-rose-600 p-0.5 rounded"
                      title="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1 mt-0.5">{s.title}</h4>
                  <p className="text-[11px] text-slate-500 line-clamp-2 mt-1">
                    {s.executiveSummary}
                  </p>
                  <div className="mt-2 text-[10px] text-slate-400">
                    {new Date(s.createdAt).toLocaleDateString()} · Mode: {s.mode}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Main Content Area: Detailed Summary Display */}
        <div className="lg:col-span-8">
          {selectedSummary ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-6">
              {/* Header & Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span className="font-semibold text-indigo-700">{selectedSummary.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{selectedSummary.mode} mode</span>
                    <span aria-hidden="true">·</span>
                    <span>{new Date(selectedSummary.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{selectedSummary.title}</h3>
                </div>

                {/* Actions: Audio Read Aloud & Copy */}
                <div className="flex items-center gap-2">
                  {/* Read Aloud Button */}
                  <button
                    onClick={handleToggleAudio}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                      isPlayingAudio
                        ? 'bg-rose-50 border-rose-200 text-rose-700 animate-pulse'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                    title="Audio playback with Web Speech"
                  >
                    {isPlayingAudio ? (
                      <>
                        <Pause className="h-3.5 w-3.5" />
                        <span>Stop Audio</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="h-3.5 w-3.5" />
                        <span>Listen</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              {/* 1. Executive Summary */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                  <Brain className="h-4 w-4 text-indigo-600" />
                  <span>Executive Synthesis</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                  {selectedSummary.executiveSummary}
                </div>
              </div>

              {/* 2. Key Concepts & Definitions */}
              {selectedSummary.keyConcepts && selectedSummary.keyConcepts.length > 0 && (
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <BookOpen className="h-4 w-4 text-indigo-600" />
                    <span>Key Concepts & Vocabulary</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {selectedSummary.keyConcepts.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl border border-slate-200/80 bg-white shadow-xs"
                      >
                        <h5 className="text-xs font-bold text-slate-900 text-indigo-950">
                          {item.term}
                        </h5>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {item.explanation}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. Core Takeaways */}
              {selectedSummary.takeaways && selectedSummary.takeaways.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <ListChecks className="h-4 w-4 text-emerald-600" />
                    <span>High-Yield Takeaways</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-700 pl-1">
                    {selectedSummary.takeaways.map((takeaway, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-[10px] font-bold text-emerald-700">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed pt-0.5">{takeaway}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* 4. Mindmap Outline Hierarchy */}
              {selectedSummary.mindmapOutline && selectedSummary.mindmapOutline.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <Network className="h-4 w-4 text-purple-600" />
                    <span>Mindmap Outline Breakdown</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-purple-50/40 border border-purple-100 font-mono text-xs text-slate-700 space-y-1.5">
                    {selectedSummary.mindmapOutline.map((node, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="text-purple-400">↳</span>
                        <span>{node}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 5. Self-Testing Evaluation Questions */}
              {selectedSummary.suggestedQuestions && selectedSummary.suggestedQuestions.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <HelpCircle className="h-4 w-4 text-amber-600" />
                    <span>Self-Assessment Comprehension Questions</span>
                  </div>
                  <div className="space-y-2">
                    {selectedSummary.suggestedQuestions.map((q, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border border-amber-200/60 bg-amber-50/30 text-xs text-slate-800"
                      >
                        <span className="font-semibold text-amber-800">Q{idx + 1}: </span>
                        <span>{q}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-200 p-12 text-center text-xs text-slate-400">
              Select or generate a summary to view detailed concepts.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
