import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  FileText,
  Layers,
  HelpCircle,
  Calendar,
  Flame,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  Plus,
  BookOpen,
  MessageSquare,
  Award,
} from 'lucide-react';
import { User, StudyMaterial, StudyPlan, ProgressMetrics, QuizAttempt } from '../types';
import { api } from '../services/api';

interface DashboardViewProps {
  user: User;
  onNavigate: (tab: string, meta?: any) => void;
  onOpenUpload: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  onNavigate,
  onOpenUpload,
}) => {
  const [metrics, setMetrics] = useState<ProgressMetrics | null>(null);
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [activePlan, setActivePlan] = useState<StudyPlan | null>(null);
  const [recentAttempts, setRecentAttempts] = useState<QuizAttempt[]>([]);
  const [recentActivities, setRecentActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const [progData, matData, plansData] = await Promise.all([
        api.getProgressDashboard(),
        api.getMaterials(),
        api.getStudyPlans(),
      ]);

      setMetrics(progData.metrics);
      setRecentActivities(progData.recentActivities || []);
      setRecentAttempts(progData.recentAttempts || []);
      setMaterials(matData.materials.slice(0, 4));
      if (plansData.studyPlans && plansData.studyPlans.length > 0) {
        setActivePlan(plansData.studyPlans[0]);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleTask = async (taskId: string) => {
    if (!activePlan) return;
    try {
      const res = await api.toggleTaskCompleted(activePlan.id, taskId);
      setActivePlan(res.studyPlan);
      // Reload metrics in background
      api.getProgressDashboard().then((d) => setMetrics(d.metrics));
    } catch (e) {
      console.error(e);
    }
  };

  if (loading && !metrics) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-3 border-indigo-600 border-t-transparent" />
          <p className="text-xs font-medium text-slate-500">Loading your learning workspace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 p-6 sm:p-8 text-white shadow-lg">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-indigo-200">
            <span>Goal: {user.learningGoal || 'Master core subject domains'}</span>
            <span aria-hidden="true">·</span>
            <span>Target: {user.targetExam || 'Academics'}</span>
            <span aria-hidden="true">·</span>
            <span>{user.studyHoursPerDay || 3} Hours / Day</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {user.name.split(' ')[0]}! Ready to retain more today?
          </h2>

          <p className="text-sm text-indigo-100/90 leading-relaxed">
            Your materials are synced with the Gemini 3.8 Flash learning engine. Generate active
            recall summaries, test your retention with quizzes, or follow your daily study sprint.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onOpenUpload}
              className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3.5 py-2 text-xs font-bold text-indigo-950 shadow-sm hover:bg-indigo-50 transition-colors"
            >
              <Plus className="h-4 w-4 text-indigo-600" />
              <span>Upload Study Material</span>
            </button>

            <button
              onClick={() => onNavigate('quizzes')}
              className="inline-flex items-center gap-1.5 rounded-lg border border-indigo-300/40 bg-indigo-700/60 backdrop-blur-xs px-3.5 py-2 text-xs font-bold text-white hover:bg-indigo-700 transition-colors"
            >
              <HelpCircle className="h-4 w-4 text-indigo-200" />
              <span>Take Practice Quiz</span>
            </button>

            <button
              onClick={() => onNavigate('tutor')}
              className="inline-flex items-center gap-1.5 rounded-lg border border-indigo-300/40 bg-indigo-700/60 backdrop-blur-xs px-3.5 py-2 text-xs font-bold text-white hover:bg-indigo-700 transition-colors"
            >
              <MessageSquare className="h-4 w-4 text-indigo-200" />
              <span>Ask AI Tutor</span>
            </button>
          </div>
        </div>

        {/* Subtle decorative background glow */}
        <div className="pointer-events-none absolute -right-12 -top-12 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="pointer-events-none absolute right-48 -bottom-16 h-64 w-64 rounded-full bg-purple-500/20 blur-3xl" />
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Streak */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Active Study Streak</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
              <Flame className="h-4 w-4 fill-amber-500" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">
              {metrics?.studyStreakDays || 5}
            </span>
            <span className="text-xs font-medium text-slate-500">consecutive days</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 font-medium flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            <span>Top 5% of active students</span>
          </div>
        </div>

        {/* Flashcards Mastered */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Flashcard Retention</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
              <Layers className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">
              {metrics?.cardMasteryPercentage || 0}%
            </span>
            <span className="text-xs font-medium text-slate-500">
              ({metrics?.masteredCards || 0}/{metrics?.totalCards || 0} cards)
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${metrics?.cardMasteryPercentage || 0}%` }}
            />
          </div>
        </div>

        {/* Quiz Avg Score */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Average Quiz Score</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
              <Award className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">
              {metrics?.avgQuizScore || 0}%
            </span>
            <span className="text-xs font-medium text-slate-500">
              across {metrics?.totalQuizAttempts || 0} attempts
            </span>
          </div>
          <p className="mt-2 text-[11px] text-slate-500">
            Highest score achieved: <strong className="text-slate-800">{metrics?.highestScore || 0}%</strong>
          </p>
        </div>

        {/* Study Plan Completion */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Study Roadmap Tasks</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
              <Calendar className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">
              {metrics?.planCompletionRate || 0}%
            </span>
            <span className="text-xs font-medium text-slate-500">
              ({metrics?.completedPlanTasks || 0}/{metrics?.totalPlanTasks || 0} tasks)
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${metrics?.planCompletionRate || 0}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content Split: Materials & Study Plan */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Recent Study Materials */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Study Materials Library</h3>
              <p className="text-xs text-slate-500">Uploaded notes and documents ready for AI generation</p>
            </div>
            <button
              onClick={() => onNavigate('materials')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              <span>View All ({metrics?.totalMaterials || 0})</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-3">
            {materials.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 bg-white p-8 text-center">
                <BookOpen className="mx-auto h-8 w-8 text-slate-300 mb-2" />
                <p className="text-xs font-semibold text-slate-700">No study materials uploaded yet</p>
                <p className="text-xs text-slate-400 mt-1 mb-4">
                  Add your lecture notes, textbook chapters, or articles to get started.
                </p>
                <button
                  onClick={onOpenUpload}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-700"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Upload Document</span>
                </button>
              </div>
            ) : (
              materials.map((mat) => (
                <div
                  key={mat.id}
                  className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs hover:border-slate-300 transition-all space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                        onClick={() => onNavigate('materials', { openMaterialId: mat.id })}>
                        {mat.title}
                      </h4>
                      {/* Zero-Pill Typography */}
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                        <span className="font-medium text-slate-700">{mat.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{mat.wordCount} words</span>
                        <span aria-hidden="true">·</span>
                        <span>~{mat.readingTimeMin} min read</span>
                        <span aria-hidden="true">·</span>
                        <span>{mat.fileType.toUpperCase()}</span>
                      </div>
                    </div>
                  </div>

                  {/* One-Click AI Action Strip */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100">
                    <button
                      onClick={() => onNavigate('summaries', { generateForMaterial: mat })}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded transition-colors"
                    >
                      <Sparkles className="h-3 w-3" />
                      <span>Summary</span>
                    </button>
                    <button
                      onClick={() => onNavigate('flashcards', { generateForMaterial: mat })}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded transition-colors"
                    >
                      <Layers className="h-3 w-3" />
                      <span>Flashcards</span>
                    </button>
                    <button
                      onClick={() => onNavigate('quizzes', { generateForMaterial: mat })}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 px-2 py-1 rounded transition-colors"
                    >
                      <HelpCircle className="h-3 w-3" />
                      <span>Quiz</span>
                    </button>
                    <button
                      onClick={() => onNavigate('tutor', { materialContextId: mat.id })}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded transition-colors"
                    >
                      <MessageSquare className="h-3 w-3" />
                      <span>Ask Tutor</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Active Study Plan & Quick Checklist */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Today's Study Plan</h3>
              <p className="text-xs text-slate-500">
                {activePlan ? activePlan.title : 'Structured daily roadmap'}
              </p>
            </div>
            <button
              onClick={() => onNavigate('studyplans')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              <span>Manage Plan</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs space-y-3">
            {activePlan ? (
              <>
                <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-100">
                  <span className="font-semibold text-slate-700">Exam: {activePlan.goal}</span>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {activePlan.tasks.filter((t) => t.completed).length} / {activePlan.tasks.length} tasks done
                  </span>
                </div>

                <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                  {activePlan.tasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      className={`group flex items-start gap-2.5 p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                        task.completed
                          ? 'border-emerald-100 bg-emerald-50/40 text-slate-500'
                          : 'border-slate-200/80 bg-white hover:border-slate-300 text-slate-900'
                      }`}
                    >
                      <button
                        type="button"
                        className="shrink-0 mt-0.5 focus:outline-none"
                        aria-label="Toggle task"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-600 fill-emerald-100" />
                        ) : (
                          <div className="h-4 w-4 rounded-full border border-slate-300 group-hover:border-indigo-500" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <p
                            className={`text-xs font-semibold truncate ${
                              task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                            }`}
                          >
                            {task.dayName}: {task.topic}
                          </p>
                          <span
                            className={`text-[10px] font-semibold uppercase tracking-wider shrink-0 ${
                              task.priority === 'high'
                                ? 'text-rose-600'
                                : task.priority === 'medium'
                                ? 'text-amber-600'
                                : 'text-slate-400'
                            }`}
                          >
                            {task.priority}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                          {task.activity}
                        </p>
                        <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-400">
                          <Clock className="h-3 w-3" />
                          <span>{task.durationMinutes} mins</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="p-6 text-center">
                <Calendar className="mx-auto h-8 w-8 text-slate-300 mb-2" />
                <p className="text-xs font-semibold text-slate-700">No active study plan</p>
                <p className="text-xs text-slate-400 mt-1 mb-3">
                  Let AI design an optimal day-by-day exam preparation timetable.
                </p>
                <button
                  onClick={() => onNavigate('studyplans')}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-700"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Generate AI Study Plan</span>
                </button>
              </div>
            )}
          </div>

          {/* Recent Quiz Attempts Card */}
          {recentAttempts.length > 0 && (
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs space-y-2">
              <h4 className="text-xs font-bold text-slate-900">Recent Quiz Performance</h4>
              <div className="space-y-1.5">
                {recentAttempts.slice(0, 2).map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-50 text-xs"
                  >
                    <div>
                      <p className="font-semibold text-slate-800">{att.quizTitle}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(att.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <span
                      className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                        att.percentage >= 80
                          ? 'bg-emerald-100 text-emerald-800'
                          : att.percentage >= 60
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {att.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
