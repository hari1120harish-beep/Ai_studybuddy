import React, { useState, useEffect } from 'react';
import {
  Layers,
  Sparkles,
  RotateCw,
  Shuffle,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Trash2,
  Eye,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Plus,
} from 'lucide-react';
import { FlashcardDeck, FlashcardItem, StudyMaterial } from '../types';
import { api } from '../services/api';

interface FlashcardsViewProps {
  initialMaterial?: StudyMaterial | null;
}

export const FlashcardsView: React.FC<FlashcardsViewProps> = ({ initialMaterial }) => {
  const [decks, setDecks] = useState<FlashcardDeck[]>([]);
  const [selectedDeck, setSelectedDeck] = useState<FlashcardDeck | null>(null);
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);

  // Active study session state
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // AI Generator state
  const [showGenerator, setShowGenerator] = useState(false);
  const [selectedMatId, setSelectedMatId] = useState<string>(initialMaterial?.id || '');
  const [topic, setTopic] = useState<string>(initialMaterial?.title || '');
  const [cardCount, setCardCount] = useState<number>(8);
  const [generating, setGenerating] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [decksRes, matRes] = await Promise.all([
        api.getFlashcardDecks(),
        api.getMaterials(),
      ]);
      setDecks(decksRes.decks || []);
      setMaterials(matRes.materials || []);

      if (decksRes.decks && decksRes.decks.length > 0 && !selectedDeck) {
        setSelectedDeck(decksRes.decks[0]);
      }
    } catch (err) {
      console.error('Failed to load flashcard decks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (initialMaterial) {
      setSelectedMatId(initialMaterial.id);
      setTopic(initialMaterial.title);
      setShowGenerator(true);
    }
  }, [initialMaterial]);

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedDeck || selectedDeck.cards.length === 0) return;

      if (e.code === 'Space') {
        e.preventDefault();
        setIsFlipped((prev) => !prev);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleNextCard();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handlePrevCard();
      } else if (e.key === '1') {
        handleRateCard('hard');
      } else if (e.key === '2') {
        handleRateCard('medium');
      } else if (e.key === '3') {
        handleRateCard('easy');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedDeck, currentCardIndex]);

  const currentCard: FlashcardItem | undefined = selectedDeck?.cards[currentCardIndex];

  const handleNextCard = () => {
    if (!selectedDeck) return;
    setIsFlipped(false);
    setShowHint(false);
    setCurrentCardIndex((prev) => (prev + 1) % selectedDeck.cards.length);
  };

  const handlePrevCard = () => {
    if (!selectedDeck) return;
    setIsFlipped(false);
    setShowHint(false);
    setCurrentCardIndex((prev) => (prev === 0 ? selectedDeck.cards.length - 1 : prev - 1));
  };

  const handleRateCard = async (rating: 'easy' | 'medium' | 'hard') => {
    if (!selectedDeck || !currentCard) return;

    try {
      const res = await api.reviewFlashcard(selectedDeck.id, currentCard.id, rating);
      // Update local deck
      setSelectedDeck(res.deck);
      setDecks((prev) => prev.map((d) => (d.id === res.deck.id ? res.deck : d)));

      // Auto advance to next card
      handleNextCard();
    } catch (e) {
      console.error(e);
    }
  };

  const handleShuffle = () => {
    if (!selectedDeck) return;
    const shuffled = [...selectedDeck.cards].sort(() => Math.random() - 0.5);
    setSelectedDeck({ ...selectedDeck, cards: shuffled });
    setCurrentCardIndex(0);
    setIsFlipped(false);
    setShowHint(false);
  };

  const handleGenerateDeck = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatId && !topic.trim()) return;

    setGenerating(true);
    try {
      let content = '';
      if (selectedMatId) {
        const mat = materials.find((m) => m.id === selectedMatId);
        if (mat) content = mat.content;
      }

      const res = await api.generateFlashcards({
        materialId: selectedMatId || undefined,
        topic: topic.trim() || 'Study Deck',
        count: cardCount,
        content: content || undefined,
      });

      setDecks((prev) => [res.deck, ...prev]);
      setSelectedDeck(res.deck);
      setCurrentCardIndex(0);
      setIsFlipped(false);
      setShowGenerator(false);
    } catch (err: any) {
      alert(err.message || 'Failed to generate flashcards.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteDeck = async (id: string) => {
    if (!confirm('Are you sure you want to delete this flashcard deck?')) return;
    try {
      await api.deleteDeck(id);
      const remaining = decks.filter((d) => d.id !== id);
      setDecks(remaining);
      if (selectedDeck?.id === id) {
        setSelectedDeck(remaining[0] || null);
        setCurrentCardIndex(0);
      }
    } catch (err) {
      alert('Failed to delete deck.');
    }
  };

  // Stats calculation
  const totalInDeck = selectedDeck?.cards.length || 0;
  const masteredInDeck = selectedDeck?.cards.filter((c) => c.masteryLevel === 'mastered').length || 0;
  const learningInDeck = selectedDeck?.cards.filter((c) => c.masteryLevel === 'learning').length || 0;
  const newInDeck = totalInDeck - masteredInDeck - learningInDeck;

  return (
    <div className={`space-y-6 pb-12 ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-900 p-6 overflow-y-auto' : ''}`}>
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl font-bold tracking-tight ${isFullscreen ? 'text-white' : 'text-slate-900'}`}>
            Active Recall Flashcards
          </h2>
          <p className={`text-xs ${isFullscreen ? 'text-slate-400' : 'text-slate-500'}`}>
            Supercharge retention using spaced repetition with instant 3D card flips.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowGenerator(!showGenerator)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-700"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Generate Deck with AI</span>
          </button>

          {selectedDeck && (
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className={`p-2 rounded-lg border text-xs font-semibold ${
                isFullscreen
                  ? 'border-slate-700 bg-slate-800 text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Study Mode'}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
          )}
        </div>
      </div>

      {/* AI Deck Generator Panel */}
      {showGenerator && (
        <div className="rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50/60 to-white p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Create Flashcards Deck with Gemini AI
              </h3>
            </div>
            <button
              onClick={() => setShowGenerator(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleGenerateDeck} className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Source Study Material
              </label>
              <select
                value={selectedMatId}
                onChange={(e) => {
                  setSelectedMatId(e.target.value);
                  const mat = materials.find((m) => m.id === e.target.value);
                  if (mat) setTopic(mat.title);
                }}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="">-- Select Material --</option>
                {materials.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Deck Topic Name
              </label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Operating Systems Paging"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="flex gap-2">
              <div className="w-24">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Card Count
                </label>
                <select
                  value={cardCount}
                  onChange={(e) => setCardCount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={5}>5 Cards</option>
                  <option value={8}>8 Cards</option>
                  <option value={12}>12 Cards</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={generating}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs disabled:opacity-50"
              >
                {generating ? (
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <span>Generate Deck</span>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Flashcards Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Decks Selector */}
        {!isFullscreen && (
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Flashcard Decks ({decks.length})
            </h3>

            <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
              {decks.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-xs text-slate-400">
                  No decks available. Generate one with AI!
                </div>
              ) : (
                decks.map((deck) => (
                  <div
                    key={deck.id}
                    onClick={() => {
                      setSelectedDeck(deck);
                      setCurrentCardIndex(0);
                      setIsFlipped(false);
                      setShowHint(false);
                    }}
                    className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedDeck?.id === deck.id
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <span className="text-[10px] font-bold uppercase text-indigo-600">
                        {deck.category}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteDeck(deck.id);
                        }}
                        className="text-slate-300 hover:text-rose-600 p-0.5"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1">
                      {deck.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{deck.description}</p>
                    <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                      <span>{deck.cards.length} cards</span>
                      <span className="text-emerald-600 font-medium">
                        {deck.cards.filter((c) => c.masteryLevel === 'mastered').length} mastered
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Right: Active Card Arena */}
        <div className={isFullscreen ? 'lg:col-span-12 max-w-3xl mx-auto w-full' : 'lg:col-span-8'}>
          {selectedDeck && currentCard ? (
            <div className="space-y-4">
              {/* Arena Controls Bar */}
              <div
                className={`flex items-center justify-between px-4 py-2.5 rounded-xl border ${
                  isFullscreen
                    ? 'border-slate-800 bg-slate-800/80 text-white'
                    : 'border-slate-200 bg-white text-slate-700'
                }`}
              >
                <div className="flex items-center gap-3 text-xs">
                  <span className="font-bold">
                    Card {currentCardIndex + 1} of {totalInDeck}
                  </span>
                  <span aria-hidden="true" className="text-slate-300">|</span>
                  <span className="text-emerald-500 font-semibold">{masteredInDeck} Mastered</span>
                  <span className="text-amber-500 font-semibold">{learningInDeck} Learning</span>
                  <span className="text-slate-400">{newInDeck} New</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleShuffle}
                    className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-slate-800"
                    title="Shuffle Deck"
                  >
                    <Shuffle className="h-4 w-4" />
                  </button>
                  {currentCard.hint && (
                    <button
                      onClick={() => setShowHint(!showHint)}
                      className={`flex items-center gap-1 px-2 py-1 text-xs font-medium rounded ${
                        showHint ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Eye className="h-3 w-3" />
                      <span>{showHint ? 'Hide Hint' : 'Hint'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* 3D Flip Card Container */}
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className="relative min-h-[320px] sm:min-h-[380px] w-full rounded-2xl cursor-pointer select-none transition-transform duration-200 hover:scale-[1.005] group"
                style={{ perspective: '1000px' }}
              >
                <div
                  className={`relative h-full w-full rounded-2xl border transition-all duration-500 shadow-md ${
                    isFlipped
                      ? 'border-indigo-200 bg-gradient-to-br from-indigo-900 to-slate-900 text-white'
                      : isFullscreen
                      ? 'border-slate-700 bg-slate-800 text-white'
                      : 'border-slate-200 bg-white text-slate-900'
                  }`}
                  style={{
                    transformStyle: 'preserve-3d',
                    minHeight: '340px',
                  }}
                >
                  {/* Card Header Stamp */}
                  <div className="p-6 flex items-center justify-between border-b border-slate-100/10">
                    <span className="text-[11px] font-bold uppercase tracking-wider opacity-75">
                      {isFlipped ? 'Answer & Explanation' : 'Recall Prompt'} · {currentCard.topic || selectedDeck.title}
                    </span>
                    <span className="text-[10px] font-mono opacity-50">Click or Space to flip</span>
                  </div>

                  {/* Card Content Body */}
                  <div className="p-8 flex flex-col justify-center items-center text-center min-h-[200px]">
                    <p className="text-base sm:text-lg font-bold leading-relaxed max-w-xl">
                      {isFlipped ? currentCard.back : currentCard.front}
                    </p>

                    {/* Hint reveal */}
                    {showHint && !isFlipped && currentCard.hint && (
                      <div className="mt-4 p-2.5 rounded-lg bg-amber-50 text-amber-800 text-xs border border-amber-200 animate-in fade-in">
                        <strong>Hint:</strong> {currentCard.hint}
                      </div>
                    )}
                  </div>

                  {/* Card Footer Status */}
                  <div className="p-4 border-t border-slate-100/10 flex items-center justify-between text-xs opacity-75">
                    <span>Reviewed: {currentCard.reviewCount || 0} times</span>
                    <span className="capitalize font-semibold">
                      Mastery: {currentCard.masteryLevel}
                    </span>
                  </div>
                </div>
              </div>

              {/* Spaced Repetition Rating Buttons */}
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => handleRateCard('hard')}
                    className="flex flex-col items-center justify-center py-2.5 px-3 rounded-xl border border-rose-200 bg-rose-50/60 hover:bg-rose-100 text-rose-800 font-bold transition-colors"
                  >
                    <span className="text-xs">Hard (Need Review)</span>
                    <span className="text-[10px] font-normal text-rose-600 mt-0.5">Press '1'</span>
                  </button>

                  <button
                    onClick={() => handleRateCard('medium')}
                    className="flex flex-col items-center justify-center py-2.5 px-3 rounded-xl border border-amber-200 bg-amber-50/60 hover:bg-amber-100 text-amber-800 font-bold transition-colors"
                  >
                    <span className="text-xs">Good (Learning)</span>
                    <span className="text-[10px] font-normal text-amber-600 mt-0.5">Press '2'</span>
                  </button>

                  <button
                    onClick={() => handleRateCard('easy')}
                    className="flex flex-col items-center justify-center py-2.5 px-3 rounded-xl border border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100 text-emerald-800 font-bold transition-colors"
                  >
                    <span className="text-xs">Easy (Mastered)</span>
                    <span className="text-[10px] font-normal text-emerald-600 mt-0.5">Press '3'</span>
                  </button>
                </div>

                {/* Navigation Arrows */}
                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={handlePrevCard}
                    className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                      isFullscreen
                        ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    <span>Previous (←)</span>
                  </button>

                  <span className="text-xs text-slate-400">Spacebar to Flip</span>

                  <button
                    onClick={handleNextCard}
                    className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                      isFullscreen
                        ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>Next (→)</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-200 p-12 text-center text-xs text-slate-400">
              Select or generate a flashcard deck to begin active recall practice.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
