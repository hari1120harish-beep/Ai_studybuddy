import React, { useState, useEffect } from 'react';
import {
  HelpCircle,
  Sparkles,
  Clock,
  CheckCircle2,
  XCircle,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  Award,
  AlertTriangle,
  History,
  Trash2,
} from 'lucide-react';
import { Quiz, QuizAttempt, StudyMaterial } from '../types';
import { api } from '../services/api';

interface QuizViewProps {
  initialMaterial?: StudyMaterial | null;
}

export const QuizView: React.FC<QuizViewProps> = ({ initialMaterial }) => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);

  // Active quiz session states
  const [isTakingQuiz, setIsTakingQuiz] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState(0);
  const [lastAttemptResult, setLastAttemptResult] = useState<QuizAttempt | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Generator form states
  const [showGenerator, setShowGenerator] = useState(false);
  const [selectedMatId, setSelectedMatId] = useState<string>(initialMaterial?.id || '');
  const [topic, setTopic] = useState<string>(initialMaterial?.title || '');
  const [numQuestions, setNumQuestions] = useState<number>(5);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [generating, setGenerating] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [quizRes, attemptsRes, matRes] = await Promise.all([
        api.getQuizzes(),
        api.getQuizAttemptsHistory(),
        api.getMaterials(),
      ]);
      setQuizzes(quizRes.quizzes || []);
      setAttempts(attemptsRes.attempts || []);
      setMaterials(matRes.materials || []);

      if (quizRes.quizzes && quizRes.quizzes.length > 0 && !selectedQuiz) {
        setSelectedQuiz(quizRes.quizzes[0]);
      }
    } catch (err) {
      console.error('Failed to load quiz data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (initialMaterial) {
      setSelectedMatId(initialMaterial.id);
      setTopic(initialMaterial.title);
      setShowGenerator(true);
    }
  }, [initialMaterial]);

  // Timer tick
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isTakingQuiz && timeRemainingSeconds > 0) {
      timer = setInterval(() => {
        setTimeRemainingSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            handleSubmitQuiz();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isTakingQuiz, timeRemainingSeconds]);

  const handleStartQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setUserAnswers({});
    setCurrentQuestionIndex(0);
    setLastAttemptResult(null);
    setTimeRemainingSeconds(quiz.timeLimitMinutes * 60);
    setIsTakingQuiz(true);
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setUserAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleSubmitQuiz = async () => {
    if (!selectedQuiz || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const timeSpent = selectedQuiz.timeLimitMinutes * 60 - timeRemainingSeconds;
      const res = await api.submitQuizAttempt(selectedQuiz.id, {
        userAnswers,
        timeSpentSeconds: Math.max(10, timeSpent),
      });

      setLastAttemptResult(res.attempt);
      setAttempts((prev) => [res.attempt, ...prev]);
      setIsTakingQuiz(false);
    } catch (err: any) {
      alert(err.message || 'Failed to submit quiz attempt.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGenerateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatId && !topic.trim()) return;

    setGenerating(true);
    try {
      let content = '';
      if (selectedMatId) {
        const mat = materials.find((m) => m.id === selectedMatId);
        if (mat) content = mat.content;
      }

      const res = await api.generateQuiz({
        materialId: selectedMatId || undefined,
        topic: topic.trim() || 'Exam Prep',
        numQuestions,
        difficulty,
        content: content || undefined,
      });

      setQuizzes((prev) => [res.quiz, ...prev]);
      setSelectedQuiz(res.quiz);
      setShowGenerator(false);
      handleStartQuiz(res.quiz);
    } catch (err: any) {
      alert(err.message || 'Failed to generate quiz.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteQuiz = async (id: string) => {
    if (!confirm('Are you sure you want to delete this quiz?')) return;
    try {
      await api.deleteQuiz(id);
      const remaining = quizzes.filter((q) => q.id !== id);
      setQuizzes(remaining);
      if (selectedQuiz?.id === id) {
        setSelectedQuiz(remaining[0] || null);
        setIsTakingQuiz(false);
        setLastAttemptResult(null);
      }
    } catch (err) {
      alert('Failed to delete quiz.');
    }
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Practice Exam Arena</h2>
          <p className="text-xs text-slate-500">
            Generate diagnostic tests with instant scoring and AI pedagogical explanations.
          </p>
        </div>

        <button
          onClick={() => {
            setShowGenerator(!showGenerator);
            setIsTakingQuiz(false);
            setLastAttemptResult(null);
          }}
          className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-700"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>Generate New Quiz with AI</span>
        </button>
      </div>

      {/* Generator Modal / Drawer */}
      {showGenerator && (
        <div className="rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50/60 to-white p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Create AI Exam with Gemini
              </h3>
            </div>
            <button
              onClick={() => setShowGenerator(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleGenerateQuiz} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Source Material
              </label>
              <select
                value={selectedMatId}
                onChange={(e) => {
                  setSelectedMatId(e.target.value);
                  const mat = materials.find((m) => m.id === e.target.value);
                  if (mat) setTopic(mat.title);
                }}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="">-- Select Material --</option>
                {materials.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Exam Subject / Topic
              </label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Neural Networks & Calculus"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Questions
                </label>
                <select
                  value={numQuestions}
                  onChange={(e) => setNumQuestions(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={3}>3 Qs</option>
                  <option value={5}>5 Qs</option>
                  <option value={8}>8 Qs</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Difficulty
                </label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={generating}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs disabled:opacity-50"
            >
              {generating ? (
                <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <span>Generate & Start</span>
              )}
            </button>
          </form>
        </div>
      )}

      {/* Main Split: Quizzes List Sidebar & Active Arena */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Sidebar: Quizzes & Past Attempts */}
        <div className="lg:col-span-4 space-y-4">
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Available Quizzes ({quizzes.length})
            </h3>
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {quizzes.map((quiz) => (
                <div
                  key={quiz.id}
                  onClick={() => {
                    setSelectedQuiz(quiz);
                    setIsTakingQuiz(false);
                    setLastAttemptResult(null);
                  }}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    selectedQuiz?.id === quiz.id && !isTakingQuiz && !lastAttemptResult
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-[10px] font-bold uppercase text-indigo-600">
                      {quiz.topic}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteQuiz(quiz.id);
                      }}
                      className="text-slate-300 hover:text-rose-600 p-0.5"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1">{quiz.title}</h4>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                    <span>{quiz.questions.length} Questions</span>
                    <span>{quiz.timeLimitMinutes} mins limit</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Past Attempts History */}
          {attempts.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <History className="h-3.5 w-3.5 text-slate-400" />
                <span>Past Attempt Scores</span>
              </h3>
              <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                {attempts.map((att) => (
                  <div
                    key={att.id}
                    onClick={() => {
                      const matchingQuiz = quizzes.find((q) => q.id === att.quizId);
                      if (matchingQuiz) setSelectedQuiz(matchingQuiz);
                      setLastAttemptResult(att);
                      setIsTakingQuiz(false);
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                      lastAttemptResult?.id === att.id
                        ? 'border-indigo-500 bg-indigo-50'
                        : 'border-slate-100 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-slate-800 line-clamp-1">{att.quizTitle}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(att.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <span
                      className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                        att.percentage >= 80
                          ? 'bg-emerald-100 text-emerald-800'
                          : att.percentage >= 60
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {att.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Main Arena: Taking Exam OR Reviewing Score OR Ready Screen */}
        <div className="lg:col-span-8">
          {/* State 1: Active Exam Mode */}
          {isTakingQuiz && selectedQuiz && (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6">
              {/* Exam Header with Live Timer */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider">
                    Timed Practice Exam
                  </span>
                  <h3 className="text-base font-bold text-slate-900">{selectedQuiz.title}</h3>
                </div>

                <div
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-mono text-xs font-bold ${
                    timeRemainingSeconds < 60
                      ? 'bg-rose-100 text-rose-700 animate-pulse'
                      : 'bg-slate-100 text-slate-800'
                  }`}
                >
                  <Clock className="h-4 w-4" />
                  <span>{formatTimer(timeRemainingSeconds)}</span>
                </div>
              </div>

              {/* Question Navigator Palette */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {selectedQuiz.questions.map((q, idx) => {
                  const isAnswered = userAnswers[q.id] !== undefined;
                  const isCurrent = currentQuestionIndex === idx;
                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestionIndex(idx)}
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold transition-all ${
                        isCurrent
                          ? 'ring-2 ring-indigo-600 bg-indigo-600 text-white'
                          : isAnswered
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              {/* Active Question Box */}
              {selectedQuiz.questions[currentQuestionIndex] && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-indigo-600">
                      Question {currentQuestionIndex + 1} of {selectedQuiz.questions.length}
                    </span>
                    <h4 className="text-sm sm:text-base font-bold text-slate-900 leading-relaxed">
                      {selectedQuiz.questions[currentQuestionIndex].question}
                    </h4>
                  </div>

                  {/* Multiple Choice Options */}
                  <div className="space-y-2.5">
                    {selectedQuiz.questions[currentQuestionIndex].options.map((opt, optIdx) => {
                      const qId = selectedQuiz.questions[currentQuestionIndex].id;
                      const isSelected = userAnswers[qId] === optIdx;

                      return (
                        <div
                          key={optIdx}
                          onClick={() => handleSelectOption(qId, optIdx)}
                          className={`flex items-center gap-3 p-3.5 rounded-xl border text-xs sm:text-sm cursor-pointer transition-all ${
                            isSelected
                              ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 font-semibold shadow-xs'
                              : 'border-slate-200 bg-white hover:border-slate-300 text-slate-700'
                          }`}
                        >
                          <span
                            className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                              isSelected
                                ? 'bg-indigo-600 text-white'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {String.fromCharCode(65 + optIdx)}
                          </span>
                          <span className="leading-relaxed">{opt}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Exam Navigation & Submit */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <button
                  onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
                  disabled={currentQuestionIndex === 0}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-600 rounded-lg hover:bg-slate-100 disabled:opacity-30"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Previous</span>
                </button>

                {currentQuestionIndex < selectedQuiz.questions.length - 1 ? (
                  <button
                    onClick={() =>
                      setCurrentQuestionIndex((prev) =>
                        Math.min(selectedQuiz.questions.length - 1, prev + 1)
                      )
                    }
                    className="flex items-center gap-1 px-4 py-2 text-xs font-bold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-xs"
                  >
                    <span>Next Question</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                ) : (
                  <button
                    onClick={handleSubmitQuiz}
                    disabled={isSubmitting}
                    className="flex items-center gap-1 px-5 py-2 text-xs font-bold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 shadow-xs"
                  >
                    <span>{isSubmitting ? 'Grading Answers...' : 'Submit Exam'}</span>
                    <CheckCircle2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* State 2: Results & Pedagogical Breakdown */}
          {!isTakingQuiz && lastAttemptResult && selectedQuiz && (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6">
              {/* Score Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-indigo-300">
                    Exam Completed on {new Date(lastAttemptResult.completedAt).toLocaleDateString()}
                  </span>
                  <h3 className="text-lg font-bold">{lastAttemptResult.quizTitle}</h3>
                  <p className="text-xs text-indigo-200">
                    Time spent: {Math.round(lastAttemptResult.timeSpentSeconds / 60)}m {lastAttemptResult.timeSpentSeconds % 60}s
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-3xl font-black">{lastAttemptResult.percentage}%</div>
                    <div className="text-xs text-indigo-300">
                      {lastAttemptResult.score} of {lastAttemptResult.totalQuestions} Correct
                    </div>
                  </div>
                  <button
                    onClick={() => handleStartQuiz(selectedQuiz)}
                    className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-white text-indigo-950 hover:bg-indigo-50 shadow-sm transition-colors"
                  >
                    <RotateCcw className="h-4 w-4" />
                    <span>Retake Quiz</span>
                  </button>
                </div>
              </div>

              {/* Question-by-Question Review with Explanations */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                  Detailed Answer Key & AI Pedagogical Explanations
                </h4>

                <div className="space-y-4">
                  {selectedQuiz.questions.map((q, qIdx) => {
                    const studentAnswer = lastAttemptResult.userAnswers[q.id];
                    const isCorrect = studentAnswer === q.correctAnswer;

                    return (
                      <div
                        key={q.id}
                        className={`p-4 rounded-xl border space-y-3 ${
                          isCorrect ? 'border-emerald-200 bg-emerald-50/20' : 'border-rose-200 bg-rose-50/20'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2">
                            {isCorrect ? (
                              <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                            ) : (
                              <XCircle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
                            )}
                            <div>
                              <span className="text-xs font-bold text-slate-500">
                                Question {qIdx + 1}
                              </span>
                              <h5 className="text-xs sm:text-sm font-bold text-slate-900">
                                {q.question}
                              </h5>
                            </div>
                          </div>
                        </div>

                        {/* Options breakdown */}
                        <div className="grid grid-cols-1 gap-1.5 pl-7">
                          {q.options.map((opt, optIdx) => {
                            const isChosen = studentAnswer === optIdx;
                            const isRightAnswer = q.correctAnswer === optIdx;

                            return (
                              <div
                                key={optIdx}
                                className={`p-2 rounded-lg text-xs flex items-center justify-between ${
                                  isRightAnswer
                                    ? 'bg-emerald-100/70 text-emerald-900 font-semibold'
                                    : isChosen && !isCorrect
                                    ? 'bg-rose-100 text-rose-900 font-semibold'
                                    : 'text-slate-600'
                                }`}
                              >
                                <span>
                                  {String.fromCharCode(65 + optIdx)}. {opt}
                                </span>
                                {isRightAnswer && (
                                  <span className="text-[10px] font-bold text-emerald-800">
                                    Correct Answer
                                  </span>
                                )}
                                {isChosen && !isCorrect && (
                                  <span className="text-[10px] font-bold text-rose-800">
                                    Your Answer
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>

                        {/* AI Pedagogical Explanation */}
                        <div className="ml-7 p-3 rounded-lg bg-white border border-slate-200 text-xs text-slate-700 leading-relaxed">
                          <strong className="text-indigo-900">Why this is correct: </strong>
                          {q.explanation}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* State 3: Ready to start screen */}
          {!isTakingQuiz && !lastAttemptResult && selectedQuiz && (
            <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-xs text-center space-y-4">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
                <HelpCircle className="h-7 w-7" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                  {selectedQuiz.topic}
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">{selectedQuiz.title}</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  This practice exam contains {selectedQuiz.questions.length} multiple-choice questions
                  with a {selectedQuiz.timeLimitMinutes} minute time limit.
                </p>
              </div>

              <div className="flex justify-center gap-6 text-xs text-slate-600 py-2 border-y border-slate-100 max-w-sm mx-auto">
                <div>
                  <span className="block font-bold text-slate-900">
                    {selectedQuiz.questions.length}
                  </span>
                  <span>Questions</span>
                </div>
                <div>
                  <span className="block font-bold text-slate-900">
                    {selectedQuiz.timeLimitMinutes} min
                  </span>
                  <span>Time Limit</span>
                </div>
                <div>
                  <span className="block font-bold text-slate-900">Instant</span>
                  <span>AI Feedback</span>
                </div>
              </div>

              <div>
                <button
                  onClick={() => handleStartQuiz(selectedQuiz)}
                  className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 shadow-md shadow-indigo-100 transition-all"
                >
                  <span>Begin Exam Now</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
