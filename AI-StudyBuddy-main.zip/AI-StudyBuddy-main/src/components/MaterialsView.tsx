import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  Plus,
  UploadCloud,
  Trash2,
  Download,
  Sparkles,
  Layers,
  HelpCircle,
  MessageSquare,
  BookOpen,
  X,
  FileCheck,
  Clock,
  Tag,
  AlertCircle,
} from 'lucide-react';
import { StudyMaterial } from '../types';
import { api } from '../services/api';

interface MaterialsViewProps {
  onNavigate: (tab: string, meta?: any) => void;
  openMaterialId?: string | null;
}

const CATEGORIES = [
  'All',
  'Computer Science',
  'Mathematics',
  'Biology',
  'History',
  'Physics',
  'General',
];

export const MaterialsView: React.FC<MaterialsViewProps> = ({
  onNavigate,
  openMaterialId,
}) => {
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Modals
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [viewingMaterial, setViewingMaterial] = useState<StudyMaterial | null>(null);

  // Upload modal form states
  const [uploadMode, setUploadMode] = useState<'file' | 'notes'>('notes');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Computer Science');
  const [tags, setTags] = useState('');
  const [content, setContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const fetchMaterials = async () => {
    try {
      setLoading(true);
      const res = await api.getMaterials({
        q: searchQuery,
        category: selectedCategory,
      });
      setMaterials(res.materials || []);

      if (openMaterialId) {
        const found = res.materials.find((m) => m.id === openMaterialId);
        if (found) setViewingMaterial(found);
      }
    } catch (err) {
      console.error('Failed to load materials:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaterials();
  }, [searchQuery, selectedCategory]);

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!title.trim()) {
      setFormError('Please enter a document title.');
      return;
    }

    if (uploadMode === 'file' && !selectedFile) {
      setFormError('Please select a file to upload.');
      return;
    }

    if (uploadMode === 'notes' && !content.trim()) {
      setFormError('Please enter some text or notes content.');
      return;
    }

    setSubmitting(true);
    try {
      if (uploadMode === 'file' && selectedFile) {
        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('title', title.trim());
        formData.append('category', category);
        formData.append('tags', tags);
        await api.uploadMaterial(formData);
      } else {
        await api.createNotesMaterial({
          title: title.trim(),
          category,
          tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
          content: content.trim(),
        });
      }

      setShowUploadModal(false);
      resetForm();
      fetchMaterials();
    } catch (err: any) {
      setFormError(err.message || 'Failed to upload study material.');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Computer Science');
    setTags('');
    setContent('');
    setSelectedFile(null);
    setFormError(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this study material?')) return;
    try {
      await api.deleteMaterial(id);
      setMaterials((prev) => prev.filter((m) => m.id !== id));
      if (viewingMaterial?.id === id) {
        setViewingMaterial(null);
      }
    } catch (err) {
      alert('Failed to delete material');
    }
  };

  const handleDownload = (material: StudyMaterial) => {
    const blob = new Blob([material.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = material.fileName || `${material.title.replace(/\s+/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Study Materials Manager</h2>
          <p className="text-xs text-slate-500">
            Upload, read, and manage your textbook chapters, lecture notes, and research papers.
          </p>
        </div>

        <button
          onClick={() => {
            resetForm();
            setShowUploadModal(true);
          }}
          className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-colors"
        >
          <Plus className="h-4 w-4" />
          <span>Upload Document</span>
        </button>
      </div>

      {/* Search & Category Filter Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by title, subject, tags, or content..."
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Category Tabs (Segmented control style) */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`shrink-0 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Materials List */}
      {loading ? (
        <div className="flex min-h-[30vh] items-center justify-center">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
        </div>
      ) : materials.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-12 text-center">
          <FileText className="mx-auto h-10 w-10 text-slate-300 mb-3" />
          <h3 className="text-sm font-bold text-slate-900">No study materials found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? 'Try adjusting your search terms or selecting "All" categories.'
              : 'Upload your first notes or PDF document to start generating AI study guides.'}
          </p>
          <button
            onClick={() => setShowUploadModal(true)}
            className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-indigo-700"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Upload Now</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {materials.map((mat) => (
            <div
              key={mat.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-xs hover:border-slate-300 transition-all hover:shadow-md"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[11px] font-semibold text-indigo-700 uppercase tracking-wider">
                    {mat.category}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDownload(mat)}
                      className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                      title="Download notes file"
                    >
                      <Download className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(mat.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50"
                      title="Delete material"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <h3
                  onClick={() => setViewingMaterial(mat)}
                  className="text-sm font-bold text-slate-900 cursor-pointer hover:text-indigo-600 line-clamp-2"
                >
                  {mat.title}
                </h3>

                <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">
                  {mat.content}
                </p>

                {/* Zero-Pill Typography for Metadata */}
                <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-1">
                  <span>{mat.wordCount} words</span>
                  <span aria-hidden="true">·</span>
                  <span>~{mat.readingTimeMin} min read</span>
                  <span aria-hidden="true">·</span>
                  <span>{mat.fileType.toUpperCase()}</span>
                </div>

                {mat.tags && mat.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 text-[10px] text-slate-500">
                    <Tag className="h-3 w-3 shrink-0 text-slate-400 mt-0.5" />
                    <span>{mat.tags.join(', ')}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                <button
                  onClick={() => setViewingMaterial(mat)}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <BookOpen className="h-3.5 w-3.5 text-slate-500" />
                  <span>Read Full Material</span>
                </button>

                <div className="grid grid-cols-3 gap-1">
                  <button
                    onClick={() => onNavigate('summaries', { generateForMaterial: mat })}
                    className="flex items-center justify-center gap-1 py-1 text-[11px] font-medium rounded text-indigo-700 bg-indigo-50 hover:bg-indigo-100"
                    title="Generate AI Summary"
                  >
                    <Sparkles className="h-3 w-3" />
                    <span>Summary</span>
                  </button>
                  <button
                    onClick={() => onNavigate('flashcards', { generateForMaterial: mat })}
                    className="flex items-center justify-center gap-1 py-1 text-[11px] font-medium rounded text-emerald-700 bg-emerald-50 hover:bg-emerald-100"
                    title="Generate Flashcards Deck"
                  >
                    <Layers className="h-3 w-3" />
                    <span>Cards</span>
                  </button>
                  <button
                    onClick={() => onNavigate('quizzes', { generateForMaterial: mat })}
                    className="flex items-center justify-center gap-1 py-1 text-[11px] font-medium rounded text-amber-700 bg-amber-50 hover:bg-amber-100"
                    title="Generate Quiz"
                  >
                    <HelpCircle className="h-3 w-3" />
                    <span>Quiz</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reader & Details Modal */}
      {viewingMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="flex max-h-[90vh] w-full max-w-3xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
              <div className="min-w-0 pr-4">
                <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider">
                  {viewingMaterial.category}
                </span>
                <h3 className="text-base font-bold text-slate-900 truncate">
                  {viewingMaterial.title}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownload(viewingMaterial)}
                  className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
                  title="Download"
                >
                  <Download className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setViewingMaterial(null)}
                  className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* AI Generator Strip inside reader */}
            <div className="flex flex-wrap items-center justify-between gap-2 bg-indigo-50/70 border-b border-indigo-100 px-6 py-2.5">
              <div className="flex items-center gap-2 text-xs text-indigo-900 font-semibold">
                <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                <span>Launch AI Tool with this material:</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const mat = viewingMaterial;
                    setViewingMaterial(null);
                    onNavigate('summaries', { generateForMaterial: mat });
                  }}
                  className="px-2.5 py-1 text-xs font-semibold rounded bg-white text-indigo-700 shadow-xs border border-indigo-200 hover:bg-indigo-50"
                >
                  Summary
                </button>
                <button
                  onClick={() => {
                    const mat = viewingMaterial;
                    setViewingMaterial(null);
                    onNavigate('flashcards', { generateForMaterial: mat });
                  }}
                  className="px-2.5 py-1 text-xs font-semibold rounded bg-white text-emerald-700 shadow-xs border border-emerald-200 hover:bg-emerald-50"
                >
                  Flashcards
                </button>
                <button
                  onClick={() => {
                    const mat = viewingMaterial;
                    setViewingMaterial(null);
                    onNavigate('quizzes', { generateForMaterial: mat });
                  }}
                  className="px-2.5 py-1 text-xs font-semibold rounded bg-white text-amber-700 shadow-xs border border-amber-200 hover:bg-amber-50"
                >
                  Quiz
                </button>
                <button
                  onClick={() => {
                    const mat = viewingMaterial;
                    setViewingMaterial(null);
                    onNavigate('tutor', { materialContextId: mat.id });
                  }}
                  className="px-2.5 py-1 text-xs font-semibold rounded bg-white text-slate-700 shadow-xs border border-slate-200 hover:bg-slate-50"
                >
                  Ask Tutor
                </button>
              </div>
            </div>

            {/* Reader Content Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="flex items-center gap-3 text-xs text-slate-500 pb-3 border-b border-slate-100">
                <span>{viewingMaterial.wordCount} words</span>
                <span aria-hidden="true">·</span>
                <span>~{viewingMaterial.readingTimeMin} minutes reading time</span>
                <span aria-hidden="true">·</span>
                <span>Uploaded {new Date(viewingMaterial.uploadedAt).toLocaleDateString()}</span>
              </div>

              <div className="prose prose-slate max-w-none text-xs sm:text-sm leading-relaxed text-slate-800 whitespace-pre-wrap font-sans">
                {viewingMaterial.content}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between border-t border-slate-200 px-6 py-3 bg-slate-50">
              <span className="text-xs text-slate-400">
                {viewingMaterial.fileName || 'Direct notes document'}
              </span>
              <button
                onClick={() => setViewingMaterial(null)}
                className="rounded-lg bg-slate-200 px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-300"
              >
                Close Reader
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Material Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="w-full max-w-xl rounded-2xl bg-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
              <h3 className="text-sm font-bold text-slate-900">Upload Study Material</h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Mode Selector */}
              <div className="flex rounded-lg bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => setUploadMode('notes')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                    uploadMode === 'notes'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Paste Notes / Markdown
                </button>
                <button
                  type="button"
                  onClick={() => setUploadMode('file')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-all ${
                    uploadMode === 'file'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Upload File (PDF / TXT / DOC)
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Chapter 4 - Cell Division & Mitosis"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Subject / Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
                  >
                    {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="e.g. Genetics, Exam-Prep, Lab"
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {uploadMode === 'file' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Select Document File *
                  </label>
                  <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-indigo-400 transition-colors bg-slate-50">
                    <input
                      type="file"
                      id="file-upload"
                      accept=".txt,.pdf,.doc,.docx,.md"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setSelectedFile(file);
                          if (!title) {
                            setTitle(file.name.replace(/\.[^/.]+$/, ''));
                          }
                        }
                      }}
                      className="hidden"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <UploadCloud className="mx-auto h-8 w-8 text-indigo-500 mb-2" />
                      {selectedFile ? (
                        <div className="text-xs">
                          <p className="font-semibold text-indigo-700">{selectedFile.name}</p>
                          <p className="text-slate-400 mt-0.5">
                            {(selectedFile.size / 1024).toFixed(1)} KB
                          </p>
                        </div>
                      ) : (
                        <div className="text-xs text-slate-600">
                          <span className="font-semibold text-indigo-600">Click to choose a file</span>{' '}
                          or drag & drop here
                          <p className="text-[11px] text-slate-400 mt-1">
                            PDF, TXT, DOC, DOCX, or Markdown up to 10MB
                          </p>
                        </div>
                      )}
                    </label>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Study Notes / Textbook Content *
                  </label>
                  <textarea
                    rows={8}
                    required
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Paste textbook excerpts, lecture transcript, or study notes here..."
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    {content.trim() ? content.trim().split(/\s+/).length : 0} words
                  </p>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm disabled:opacity-50"
                >
                  {submitting ? (
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <FileCheck className="h-4 w-4" />
                      <span>Save Study Material</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
