import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  Cpu,
  FileText,
  Bell,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Send,
  Sparkles,
} from 'lucide-react';
import { User, AdminAnalytics } from '../types';
import { api } from '../services/api';

export const AdminView: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [analytics, setAnalytics] = useState<AdminAnalytics | null>(null);
  const [loading, setLoading] = useState(true);

  // Broadcast Notification Form
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastType, setBroadcastType] = useState('info');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);
  const [sendingBroadcast, setSendingBroadcast] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [usersRes, analyticsRes] = await Promise.all([
        api.getAdminUsers(),
        api.getAdminAnalytics(),
      ]);
      setUsers(usersRes.users || []);
      setAnalytics(analyticsRes);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleRole = async (userId: string, currentRole: 'student' | 'admin') => {
    const newRole = currentRole === 'student' ? 'admin' : 'student';
    try {
      const res = await api.updateAdminUserRole(userId, newRole);
      setUsers((prev) => prev.map((u) => (u.id === userId ? res.user : u)));
    } catch (err: any) {
      alert(err.message || 'Failed to update user role.');
    }
  };

  const handleToggleStatus = async (userId: string, currentStatus: 'active' | 'suspended') => {
    const newStatus = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      const res = await api.updateAdminUserStatus(userId, newStatus);
      setUsers((prev) => prev.map((u) => (u.id === userId ? res.user : u)));
    } catch (err: any) {
      alert(err.message || 'Failed to update user status.');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to permanently delete this user?')) return;
    try {
      await api.deleteAdminUser(userId);
      setUsers((prev) => prev.filter((u) => u.id !== userId));
    } catch (err: any) {
      alert(err.message || 'Failed to delete user.');
    }
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;

    setSendingBroadcast(true);
    try {
      await api.broadcastNotification({
        title: broadcastTitle,
        message: broadcastMessage,
        type: broadcastType,
      });
      setBroadcastSuccess(true);
      setBroadcastTitle('');
      setBroadcastMessage('');
      setTimeout(() => setBroadcastSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to broadcast notification.');
    } finally {
      setSendingBroadcast(false);
    }
  };

  if (loading || !analytics) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-600 text-white shadow-xs">
          <Shield className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Admin Control Center</h2>
          <p className="text-xs text-slate-500">
            Platform governance, user management, and Gemini AI usage telemetry.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Users</span>
            <Users className="h-4 w-4 text-purple-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {analytics.metrics.totalUsers}
          </div>
          <p className="mt-1 text-[11px] text-emerald-600 font-medium">
            {analytics.metrics.activeUsers} active accounts
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">AI Tokens Consumed</span>
            <Cpu className="h-4 w-4 text-indigo-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900 font-mono">
            {analytics.metrics.totalTokens.toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Across {analytics.metrics.aiRequestsCount} AI operations
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Study Materials</span>
            <FileText className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {analytics.metrics.totalMaterials}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            {analytics.metrics.totalSummaries} summaries created
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Practice Quizzes</span>
            <Sparkles className="h-4 w-4 text-amber-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {analytics.metrics.totalQuizzes}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            {analytics.metrics.totalAttempts} total student attempts
          </p>
        </div>
      </div>

      {/* 1. User Management Table */}
      <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Registered Users Management</h3>
            <p className="text-xs text-slate-500">Configure roles, permissions, and account status</p>
          </div>
          <span className="text-xs font-semibold text-slate-500 font-mono">
            {users.length} Users
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px] border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Target Exam / Goal</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Joined</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/60">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={u.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${u.name}`}
                        alt={u.name}
                        className="h-7 w-7 rounded-full object-cover border border-slate-200"
                      />
                      <div>
                        <div className="font-bold text-slate-900">{u.name}</div>
                        <div className="text-[11px] text-slate-500">{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">
                    <div className="font-medium text-slate-800">{u.targetExam || 'General'}</div>
                    <div className="text-[11px] text-slate-400 truncate max-w-xs">{u.learningGoal}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleToggleRole(u.id, u.role)}
                      className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase transition-colors ${
                        u.role === 'admin'
                          ? 'bg-purple-100 text-purple-800 hover:bg-purple-200'
                          : 'bg-indigo-100 text-indigo-800 hover:bg-indigo-200'
                      }`}
                      title="Click to toggle role"
                    >
                      {u.role}
                    </button>
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleToggleStatus(u.id, u.status)}
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                        u.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                      }`}
                      title="Click to toggle status"
                    >
                      {u.status}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 text-slate-500">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleDeleteUser(u.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded"
                      title="Delete User"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2. Platform AI Activity & System Notification Broadcast */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: AI Telemetry & Audit Logs */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Gemini AI Usage Breakdown</h3>
            <p className="text-xs text-slate-500">Real-time prompt tokens & service distribution</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            {analytics.actionBreakdown.map((item) => (
              <div key={item.action} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="block text-lg font-black text-slate-800">{item.count}</span>
                <span className="text-[11px] font-semibold text-slate-500 capitalize">
                  {item.action}
                </span>
              </div>
            ))}
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Recent AI Audit Invocations
            </h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {analytics.recentLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-50 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-800">{log.userName}</span>
                    <span className="text-[10px] font-mono text-indigo-600 capitalize">
                      · {log.action}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span>~{log.promptTokensEstimate} tokens</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Broadcast System Notification Form */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Broadcast Platform Announcement</h3>
            <p className="text-xs text-slate-500">
              Send an instant system-wide notification to all registered students.
            </p>
          </div>

          {broadcastSuccess && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" />
              <span>Announcement broadcasted successfully!</span>
            </div>
          )}

          <form onSubmit={handleSendBroadcast} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Announcement Title
              </label>
              <input
                type="text"
                required
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Scheduled Exam Preparation Sprint"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Notification Type
              </label>
              <select
                value={broadcastType}
                onChange={(e) => setBroadcastType(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="info">General Information</option>
                <option value="success">Achievement / Milestone</option>
                <option value="alert">Important Advisory</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Message Body
              </label>
              <textarea
                rows={3}
                required
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="Write message to students..."
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={sendingBroadcast}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-4 text-xs font-bold rounded-lg bg-purple-600 hover:bg-purple-700 text-white shadow-xs disabled:opacity-50 transition-colors"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{sendingBroadcast ? 'Sending...' : 'Broadcast to All Students'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
