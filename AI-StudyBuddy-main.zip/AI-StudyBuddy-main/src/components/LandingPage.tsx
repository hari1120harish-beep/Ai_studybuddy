import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Layers,
  HelpCircle,
  Calendar,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Brain,
  Zap,
  Lock,
  User as UserIcon,
  Mail,
  GraduationCap,
} from 'lucide-react';
import { api } from '../services/api';
import { User } from '../types';

interface LandingPageProps {
  onAuthSuccess: (user: User) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onAuthSuccess }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [targetExam, setTargetExam] = useState('');
  const [learningGoal, setLearningGoal] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isLoginMode) {
        const res = await api.login(email, password);
        onAuthSuccess(res.user);
      } else {
        const res = await api.register({
          name,
          email,
          password,
          targetExam: targetExam || 'College Academics',
          learningGoal: learningGoal || 'Master course materials and ace exams',
        });
        onAuthSuccess(res.user);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async (demoEmail: string) => {
    setError(null);
    setLoading(true);
    try {
      const res = await api.login(demoEmail, 'password123');
      onAuthSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100/60 text-slate-900">
      {/* Top Banner */}
      <header className="border-b border-slate-200/80 bg-white/70 backdrop-blur-md px-6 py-4">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-sm shadow-indigo-200">
              <BookOpen className="h-6 w-6" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900">AI StudyBuddy</span>
              <span className="hidden sm:inline-block ml-2 text-xs text-slate-500">
                · Generative AI Learning Platform
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDemoLogin('student@studybuddy.ai')}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors"
            >
              Demo Student
            </button>
            <button
              onClick={() => handleDemoLogin('admin@studybuddy.ai')}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-purple-200 bg-purple-50 text-purple-700 hover:bg-purple-100 transition-colors"
            >
              Demo Admin
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Brand Story & Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-indigo-100 bg-indigo-50/70 px-3.5 py-1 text-xs font-medium text-indigo-800">
              <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
              <span>Powered by Google Gemini 3.8 Flash & Full MERN Stack</span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Study smarter, retain faster, and master any subject with{' '}
              <span className="text-indigo-600">Generative AI</span>.
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              AI StudyBuddy transforms your lecture notes, PDFs, and textbooks into
              structured summaries, 3D spaced-repetition flashcards, adaptive practice quizzes,
              and customized daily study schedules.
            </p>

            {/* Feature Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200/80 bg-white shadow-xs">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">AI Study Summaries</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Executive briefs, core concept definitions, mindmaps, and audio read-aloud.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200/80 bg-white shadow-xs">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">3D Flashcards & Recall</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Spaced repetition algorithms to convert short-term cramming into long-term memory.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200/80 bg-white shadow-xs">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                  <HelpCircle className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Practice Exam Generator</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Realistic timed tests with step-by-step AI explanations for every question.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200/80 bg-white shadow-xs">
                <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                  <Calendar className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Personalized Study Plans</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Intelligent milestones mapped dynamically to your target exam dates and daily hours.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Demo Launchers */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <span className="text-xs font-semibold text-slate-500">1-Click Instant Login:</span>
              <div className="flex gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => handleDemoLogin('student@studybuddy.ai')}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm transition-all"
                >
                  <GraduationCap className="h-4 w-4" />
                  <span>Student Workspace</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoLogin('admin@studybuddy.ai')}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-purple-700 text-white hover:bg-purple-800 shadow-sm transition-all"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>Admin Console</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Auth Card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 shadow-xl">
              {/* Tab Selector */}
              <div className="flex rounded-lg bg-slate-100 p-1 mb-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsLoginMode(true);
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                    isLoginMode ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsLoginMode(false);
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                    !isLoginMode ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Create Account
                </button>
              </div>

              {error && (
                <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {!isLoginMode && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <UserIcon className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Alex Rivera"
                        className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="student@studybuddy.ai"
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {!isLoginMode && (
                  <>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Target Exam / Focus
                      </label>
                      <input
                        type="text"
                        value={targetExam}
                        onChange={(e) => setTargetExam(e.target.value)}
                        placeholder="e.g. GRE Computer Science, USMLE, SAT"
                        className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Primary Learning Goal
                      </label>
                      <input
                        type="text"
                        value={learningGoal}
                        onChange={(e) => setLearningGoal(e.target.value)}
                        placeholder="e.g. Master Neural Networks & Operating Systems"
                        className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-100 transition-all disabled:opacity-50"
                >
                  {loading ? (
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>{isLoginMode ? 'Sign In to Workspace' : 'Create Free Account'}</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </>
                  )}
                </button>
              </form>

              {/* Demo Credentials Hint */}
              <div className="mt-6 pt-4 border-t border-slate-100 text-center">
                <p className="text-[11px] text-slate-500">
                  Pre-configured accounts for testing:
                </p>
                <div className="mt-2 flex flex-col gap-1 text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-left">
                  <div>
                    <span className="font-semibold text-slate-800">Student:</span>{' '}
                    <code>student@studybuddy.ai</code> (pass: <code>password123</code>)
                  </div>
                  <div>
                    <span className="font-semibold text-slate-800">Admin:</span>{' '}
                    <code>admin@studybuddy.ai</code> (pass: <code>password123</code>)
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
