import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Sparkles,
  CheckCircle2,
  Clock,
  Trash2,
  Plus,
  BookOpen,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { StudyPlan, StudyMaterial } from '../types';
import { api } from '../services/api';

export const StudyPlansView: React.FC = () => {
  const [plans, setPlans] = useState<StudyPlan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<StudyPlan | null>(null);
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);

  // Generator form
  const [showGenerator, setShowGenerator] = useState(false);
  const [goal, setGoal] = useState('');
  const [title, setTitle] = useState('');
  const [examDate, setExamDate] = useState('');
  const [days, setDays] = useState(7);
  const [dailyHours, setDailyHours] = useState(3);
  const [selectedMaterialIds, setSelectedMaterialIds] = useState<string[]>([]);
  const [generating, setGenerating] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [plansRes, matRes] = await Promise.all([
        api.getStudyPlans(),
        api.getMaterials(),
      ]);
      setPlans(plansRes.studyPlans || []);
      setMaterials(matRes.materials || []);

      if (plansRes.studyPlans && plansRes.studyPlans.length > 0 && !selectedPlan) {
        setSelectedPlan(plansRes.studyPlans[0]);
      }
    } catch (err) {
      console.error('Failed to load study plans:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleTask = async (taskId: string) => {
    if (!selectedPlan) return;
    try {
      const res = await api.toggleTaskCompleted(selectedPlan.id, taskId);
      setSelectedPlan(res.studyPlan);
      setPlans((prev) => prev.map((p) => (p.id === res.studyPlan.id ? res.studyPlan : p)));
    } catch (e) {
      console.error(e);
    }
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goal.trim()) return;

    setGenerating(true);
    try {
      const res = await api.generateStudyPlan({
        title: title || `${days}-Day Sprint: ${goal}`,
        goal,
        examDate: examDate || undefined,
        days,
        dailyHours,
        materialIds: selectedMaterialIds,
      });

      setPlans((prev) => [res.studyPlan, ...prev]);
      setSelectedPlan(res.studyPlan);
      setShowGenerator(false);
      setGoal('');
      setTitle('');
    } catch (err: any) {
      alert(err.message || 'Failed to generate study plan.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDeletePlan = async (id: string) => {
    if (!confirm('Are you sure you want to delete this study plan?')) return;
    try {
      await api.deleteStudyPlan(id);
      const remaining = plans.filter((p) => p.id !== id);
      setPlans(remaining);
      if (selectedPlan?.id === id) {
        setSelectedPlan(remaining[0] || null);
      }
    } catch (err) {
      alert('Failed to delete plan.');
    }
  };

  const completedCount = selectedPlan?.tasks.filter((t) => t.completed).length || 0;
  const totalCount = selectedPlan?.tasks.length || 0;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">Personalized Study Plans</h2>
          <p className="text-xs text-slate-500">
            Tailor-made daily study schedules aligned with your upcoming exam dates and target hours.
          </p>
        </div>

        <button
          onClick={() => setShowGenerator(!showGenerator)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-700"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>Generate New Study Plan</span>
        </button>
      </div>

      {/* Generator Drawer */}
      {showGenerator && (
        <div className="rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50/60 to-white p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Create Intelligent Study Plan with Gemini
              </h3>
            </div>
            <button
              onClick={() => setShowGenerator(false)}
              className="text-xs text-slate-400 hover:text-slate-700"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleGeneratePlan} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Exam or Subject Goal *
                </label>
                <input
                  type="text"
                  required
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="e.g. GRE Computer Science & Algorithms Midterm"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Plan Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 7-Day Systems Acceleration Sprint"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Exam Date
                </label>
                <input
                  type="date"
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Duration (Days)
                </label>
                <select
                  value={days}
                  onChange={(e) => setDays(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={5}>5 Days (Intense Cram)</option>
                  <option value={7}>7 Days (Standard Sprint)</option>
                  <option value={14}>14 Days (Comprehensive)</option>
                  <option value={21}>21 Days (Semester Master)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Daily Study Hours
                </label>
                <select
                  value={dailyHours}
                  onChange={(e) => setDailyHours(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={1}>1 Hour / day</option>
                  <option value={2}>2 Hours / day</option>
                  <option value={3}>3 Hours / day</option>
                  <option value={4}>4 Hours / day</option>
                  <option value={5}>5+ Hours / day</option>
                </select>
              </div>
            </div>

            {/* Select Material Context */}
            {materials.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Link Uploaded Study Materials for Context:
                </label>
                <div className="flex flex-wrap gap-2 max-h-28 overflow-y-auto p-2 rounded-lg border border-slate-200 bg-white">
                  {materials.map((m) => {
                    const isSelected = selectedMaterialIds.includes(m.id);
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          setSelectedMaterialIds((prev) =>
                            isSelected ? prev.filter((id) => id !== m.id) : [...prev, m.id]
                          );
                        }}
                        className={`text-xs px-2.5 py-1 rounded-md border font-medium transition-colors ${
                          isSelected
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {m.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={generating}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs disabled:opacity-50"
              >
                {generating ? (
                  <>
                    <div className="h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Structuring Plan with Gemini 3.8 Flash...</span>
                  </>
                ) : (
                  <>
                    <Calendar className="h-3.5 w-3.5" />
                    <span>Generate Personalized Plan</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Split: Plans List & Active Plan View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Study Plans list */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Your Study Plans ({plans.length})
          </h3>

          <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
            {plans.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 p-6 text-center text-xs text-slate-400">
                No study plans generated yet. Create one above!
              </div>
            ) : (
              plans.map((p) => {
                const completed = p.tasks.filter((t) => t.completed).length;
                const total = p.tasks.length;
                const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedPlan(p)}
                    className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedPlan?.id === p.id
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <span className="text-[10px] font-bold uppercase text-indigo-600">
                        {p.totalDays} Days · {p.dailyHours}h/day
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeletePlan(p.id);
                        }}
                        className="text-slate-300 hover:text-rose-600 p-0.5"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1">{p.title}</h4>
                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">{p.goal}</p>

                    <div className="mt-2 space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>{completed} of {total} done</span>
                        <span className="font-semibold text-indigo-600">{pct}%</span>
                      </div>
                      <div className="h-1 w-full rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full bg-indigo-600 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Active Plan Milestone Timeline */}
        <div className="lg:col-span-8">
          {selectedPlan ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6">
              {/* Plan Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <span className="font-semibold text-indigo-700">Goal: {selectedPlan.goal}</span>
                    {selectedPlan.examDate && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>Exam: {selectedPlan.examDate}</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{selectedPlan.title}</h3>
                </div>

                {/* Progress Meter */}
                <div className="text-right">
                  <div className="text-2xl font-black text-slate-900">{completionPercentage}%</div>
                  <div className="text-xs text-slate-500">
                    {completedCount} of {totalCount} completed
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>

              {/* Day-by-Day Milestone Task List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                  Daily Study Milestones Checklist
                </h4>

                <div className="space-y-2.5">
                  {selectedPlan.tasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                        task.completed
                          ? 'border-emerald-200 bg-emerald-50/30 text-slate-500'
                          : 'border-slate-200 bg-white hover:border-slate-300 shadow-xs'
                      }`}
                    >
                      <button
                        type="button"
                        className="shrink-0 mt-0.5 focus:outline-none"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-600 fill-emerald-100" />
                        ) : (
                          <div className="h-5 w-5 rounded-full border border-slate-300 hover:border-indigo-600" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className={`text-xs font-bold ${
                              task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                            }`}
                          >
                            {task.dayName} · {task.topic}
                          </span>
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider ${
                              task.priority === 'high'
                                ? 'text-rose-600'
                                : task.priority === 'medium'
                                ? 'text-amber-600'
                                : 'text-slate-400'
                            }`}
                          >
                            {task.priority} Priority
                          </span>
                        </div>

                        <p className="text-xs text-slate-600 leading-relaxed">
                          {task.activity}
                        </p>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{task.durationMinutes} mins allocated</span>
                          </div>
                          {task.resources && task.resources.length > 0 && (
                            <div className="flex items-center gap-1 truncate">
                              <BookOpen className="h-3 w-3 text-indigo-400" />
                              <span className="truncate">{task.resources.join(', ')}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-200 p-12 text-center text-xs text-slate-400">
              Select or generate a personalized study plan to view your roadmap.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
