import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Flame,
  Award,
  Layers,
  BookOpen,
  Clock,
  TrendingUp,
  CheckCircle2,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { ProgressMetrics, QuizAttempt } from '../types';
import { api } from '../services/api';

export const ProgressView: React.FC = () => {
  const [metrics, setMetrics] = useState<ProgressMetrics | null>(null);
  const [categoryDistribution, setCategoryDistribution] = useState<Array<{ name: string; count: number }>>([]);
  const [recentActivities, setRecentActivities] = useState<any[]>([]);
  const [recentAttempts, setRecentAttempts] = useState<QuizAttempt[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getProgressDashboard()
      .then((data) => {
        setMetrics(data.metrics);
        setCategoryDistribution(data.categoryDistribution || []);
        setRecentActivities(data.recentActivities || []);
        setRecentAttempts(data.recentAttempts || []);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !metrics) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
      </div>
    );
  }

  const maxCategoryCount = Math.max(...categoryDistribution.map((c) => c.count), 1);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">Learning Progress & Analytics</h2>
        <p className="text-xs text-slate-500">
          Track active recall retention, quiz performance trends, and study streak milestones.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Streak */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Study Streak</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
              <Flame className="h-4 w-4 fill-amber-500" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {metrics.studyStreakDays} Days
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Active study consistency</p>
        </div>

        {/* Card Retention */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Flashcards Mastered</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
              <Layers className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {metrics.cardMasteryPercentage}%
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            {metrics.masteredCards} of {metrics.totalCards} cards retained
          </p>
        </div>

        {/* Quiz Avg */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Average Quiz Score</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
              <Award className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {metrics.avgQuizScore}%
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Across {metrics.totalQuizAttempts} attempts (Highest: {metrics.highestScore}%)
          </p>
        </div>

        {/* Total Hours */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Est. Study Time</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
              <Clock className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            ~{metrics.estimatedHoursSpent} Hours
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Based on reading & testing time</p>
        </div>
      </div>

      {/* Main Split: Category Breakdown & Quiz Attempts History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Category Distribution Chart & Retention Pyramid */}
        <div className="lg:col-span-6 space-y-6">
          {/* Subject Distribution */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Curriculum Topic Distribution
              </h3>
              <p className="text-xs text-slate-500">Materials and flashcard decks across subjects</p>
            </div>

            <div className="space-y-3">
              {categoryDistribution.length === 0 ? (
                <p className="text-xs text-slate-400">No subject data yet.</p>
              ) : (
                categoryDistribution.map((cat) => {
                  const pct = Math.round((cat.count / maxCategoryCount) * 100);
                  return (
                    <div key={cat.name} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700">{cat.name}</span>
                        <span className="font-mono text-slate-500">{cat.count} items</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Flashcard Mastery Distribution */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Memory Retention Stages
              </h3>
              <p className="text-xs text-slate-500">Spaced repetition distribution of your flashcards</p>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-100">
                <span className="block text-2xl font-black text-emerald-800">
                  {metrics.masteredCards}
                </span>
                <span className="text-xs font-semibold text-emerald-700">Mastered</span>
                <span className="block text-[10px] text-emerald-600 mt-1">Long-term memory</span>
              </div>

              <div className="p-4 rounded-xl bg-amber-50 border border-amber-100">
                <span className="block text-2xl font-black text-amber-800">
                  {metrics.learningCards}
                </span>
                <span className="text-xs font-semibold text-amber-700">Learning</span>
                <span className="block text-[10px] text-amber-600 mt-1">Under review</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="block text-2xl font-black text-slate-800">{metrics.newCards}</span>
                <span className="text-xs font-semibold text-slate-600">New</span>
                <span className="block text-[10px] text-slate-400 mt-1">Unstudied</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quiz Score History & Activity Feed */}
        <div className="lg:col-span-6 space-y-6">
          {/* Quiz Score History */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Recent Diagnostic Exam Scores
              </h3>
              <p className="text-xs text-slate-500">Continuous assessment evaluation</p>
            </div>

            <div className="space-y-2">
              {recentAttempts.length === 0 ? (
                <p className="text-xs text-slate-400">No quizzes completed yet.</p>
              ) : (
                recentAttempts.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100"
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{att.quizTitle}</h4>
                      <p className="text-[11px] text-slate-500">
                        {att.score}/{att.totalQuestions} correct · {Math.round(att.timeSpentSeconds / 60)} mins
                      </p>
                    </div>
                    <span
                      className={`text-xs font-bold font-mono px-2.5 py-1 rounded-md ${
                        att.percentage >= 80
                          ? 'bg-emerald-100 text-emerald-800'
                          : att.percentage >= 60
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {att.percentage}%
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Activity Log Feed */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Recent Activity Log
              </h3>
              <p className="text-xs text-slate-500">Study actions recorded across the platform</p>
            </div>

            <div className="space-y-3">
              {recentActivities.map((act) => (
                <div key={act.id} className="flex items-start gap-3 text-xs">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-indigo-600 mt-0.5">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800 truncate">{act.title}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span>{act.badge}</span>
                      <span aria-hidden="true">·</span>
                      <span>{new Date(act.timestamp).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
