export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  avatar?: string;
  targetExam?: string;
  learningGoal?: string;
  studyHoursPerDay?: number;
  createdAt: string;
  status: 'active' | 'suspended';
}

export interface StudyMaterial {
  id: string;
  userId: string;
  title: string;
  category: string;
  tags: string[];
  fileType: 'pdf' | 'doc' | 'txt' | 'notes';
  fileName?: string;
  fileSize?: string;
  content: string;
  wordCount: number;
  readingTimeMin: number;
  uploadedAt: string;
  updatedAt: string;
}

export interface Summary {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  category: string;
  mode: 'brief' | 'comprehensive' | 'key-points' | 'exam-prep';
  executiveSummary: string;
  keyConcepts: Array<{ term: string; explanation: string }>;
  takeaways: string[];
  mindmapOutline?: string[];
  suggestedQuestions?: string[];
  createdAt: string;
}

export interface FlashcardItem {
  id: string;
  front: string;
  back: string;
  hint?: string;
  topic?: string;
  masteryLevel: 'new' | 'learning' | 'mastered';
  reviewCount: number;
  lastReviewed?: string;
}

export interface FlashcardDeck {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  description: string;
  category: string;
  cards: FlashcardItem[];
  createdAt: string;
  updatedAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Quiz {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  topic: string;
  questions: QuizQuestion[];
  timeLimitMinutes: number;
  createdAt: string;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  quizId: string;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  userAnswers: Record<string, number>;
  timeSpentSeconds: number;
  completedAt: string;
}

export interface StudyPlanTask {
  id: string;
  day: number;
  dayName: string;
  topic: string;
  activity: string;
  durationMinutes: number;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  resources?: string[];
}

export interface StudyPlan {
  id: string;
  userId: string;
  title: string;
  goal: string;
  examDate?: string;
  totalDays: number;
  dailyHours: number;
  tasks: StudyPlanTask[];
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'alert' | 'streak';
  read: boolean;
  createdAt: string;
}

export interface ProgressMetrics {
  totalMaterials: number;
  totalSummaries: number;
  totalFlashcardDecks: number;
  totalCards: number;
  masteredCards: number;
  learningCards: number;
  newCards: number;
  cardMasteryPercentage: number;
  totalQuizzes: number;
  totalQuizAttempts: number;
  avgQuizScore: number;
  highestScore: number;
  totalPlanTasks: number;
  completedPlanTasks: number;
  planCompletionRate: number;
  studyStreakDays: number;
  estimatedHoursSpent: number;
}

export interface AIUsageLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  promptTokensEstimate: number;
  model: string;
  timestamp: string;
}

export interface AdminAnalytics {
  metrics: {
    totalUsers: number;
    activeUsers: number;
    totalMaterials: number;
    totalSummaries: number;
    totalFlashcardDecks: number;
    totalQuizzes: number;
    totalAttempts: number;
    totalTokens: number;
    aiRequestsCount: number;
  };
  actionBreakdown: Array<{ action: string; count: number }>;
  recentLogs: AIUsageLog[];
  materialsOverview: Array<{
    id: string;
    title: string;
    category: string;
    fileType: string;
    wordCount: number;
    ownerName: string;
    uploadedAt: string;
  }>;
}
