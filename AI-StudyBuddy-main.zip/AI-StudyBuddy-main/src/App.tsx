import React, { useState, useEffect } from 'react';
import { User, StudyMaterial } from './types';
import { api, getToken } from './services/api';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { DashboardView } from './components/DashboardView';
import { MaterialsView } from './components/MaterialsView';
import { SummariesView } from './components/SummariesView';
import { FlashcardsView } from './components/FlashcardsView';
import { QuizView } from './components/QuizView';
import { StudyPlansView } from './components/StudyPlansView';
import { AITutorView } from './components/AITutorView';
import { ProgressView } from './components/ProgressView';
import { AdminView } from './components/AdminView';
import { ProfileModal } from './components/ProfileModal';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Cross-component context handoffs
  const [openMaterialId, setOpenMaterialId] = useState<string | null>(null);
  const [summaryMaterial, setSummaryMaterial] = useState<StudyMaterial | null>(null);
  const [flashcardMaterial, setFlashcardMaterial] = useState<StudyMaterial | null>(null);
  const [quizMaterial, setQuizMaterial] = useState<StudyMaterial | null>(null);
  const [tutorMaterialId, setTutorMaterialId] = useState<string | null>(null);

  // Profile modal
  const [showProfileModal, setShowProfileModal] = useState(false);

  // Restore authenticated session on initial mount
  useEffect(() => {
    const token = getToken();
    if (token) {
      api
        .getMe()
        .then((res) => {
          setUser(res.user);
        })
        .catch(() => {
          api.logout();
          setUser(null);
        })
        .finally(() => {
          setAuthChecking(false);
        });
    } else {
      setAuthChecking(false);
    }
  }, []);

  const handleLogout = () => {
    api.logout();
    setUser(null);
    setActiveTab('dashboard');
  };

  const handleQuickSwitchUser = async (demoEmail: string) => {
    try {
      const res = await api.login(demoEmail, 'password123');
      setUser(res.user);
      setActiveTab('dashboard');
    } catch (e) {
      console.error('Quick switch error:', e);
    }
  };

  const handleNavigate = (tab: string, meta?: any) => {
    if (meta?.openMaterialId) {
      setOpenMaterialId(meta.openMaterialId);
    }
    if (meta?.generateForMaterial) {
      if (tab === 'summaries') setSummaryMaterial(meta.generateForMaterial);
      if (tab === 'flashcards') setFlashcardMaterial(meta.generateForMaterial);
      if (tab === 'quizzes') setQuizMaterial(meta.generateForMaterial);
    }
    if (meta?.materialContextId) {
      setTutorMaterialId(meta.materialContextId);
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (authChecking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-3 border-indigo-600 border-t-transparent" />
          <p className="text-xs font-semibold text-slate-500">Initializing AI StudyBuddy...</p>
        </div>
      </div>
    );
  }

  // Not logged in: Show landing page with instant demo access & auth
  if (!user) {
    return <LandingPage onAuthSuccess={(authenticatedUser) => setUser(authenticatedUser)} />;
  }

  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-900 font-sans antialiased">
      {/* Top App Navbar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
        onOpenProfile={() => setShowProfileModal(true)}
        onQuickSwitchUser={handleQuickSwitchUser}
      />

      {/* Main View Container */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            user={user}
            onNavigate={handleNavigate}
            onOpenUpload={() => handleNavigate('materials')}
          />
        )}

        {activeTab === 'materials' && (
          <MaterialsView
            onNavigate={handleNavigate}
            openMaterialId={openMaterialId}
          />
        )}

        {activeTab === 'summaries' && (
          <SummariesView initialMaterial={summaryMaterial} />
        )}

        {activeTab === 'flashcards' && (
          <FlashcardsView initialMaterial={flashcardMaterial} />
        )}

        {activeTab === 'quizzes' && (
          <QuizView initialMaterial={quizMaterial} />
        )}

        {activeTab === 'studyplans' && <StudyPlansView />}

        {activeTab === 'tutor' && (
          <AITutorView initialMaterialId={tutorMaterialId} />
        )}

        {activeTab === 'progress' && <ProgressView />}

        {activeTab === 'admin' && user.role === 'admin' && <AdminView />}
      </main>

      {/* Profile & Goals Modal */}
      {showProfileModal && (
        <ProfileModal
          user={user}
          isOpen={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          onUpdate={(updated) => setUser(updated)}
        />
      )}
    </div>
  );
}
