import {
  User,
  StudyMaterial,
  Summary,
  FlashcardDeck,
  FlashcardItem,
  Quiz,
  QuizAttempt,
  StudyPlan,
  NotificationItem,
  ProgressMetrics,
  AdminAnalytics,
} from '../types';

const TOKEN_KEY = 'studybuddy_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(options.headers || {});

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export const api = {
  // Auth
  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    const res = await request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setToken(res.token);
    return res;
  },

  async register(params: {
    name: string;
    email: string;
    password: string;
    role?: 'student' | 'admin';
    targetExam?: string;
    learningGoal?: string;
    studyHoursPerDay?: number;
  }): Promise<{ token: string; user: User }> {
    const res = await request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    setToken(res.token);
    return res;
  },

  async getMe(): Promise<{ user: User }> {
    return request<{ user: User }>('/api/auth/me');
  },

  async updateProfile(params: Partial<User>): Promise<{ user: User; message: string }> {
    return request<{ user: User; message: string }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(params),
    });
  },

  logout() {
    removeToken();
  },

  // Study Materials
  async getMaterials(params?: { q?: string; category?: string }): Promise<{ materials: StudyMaterial[]; total: number }> {
    const searchParams = new URLSearchParams();
    if (params?.q) searchParams.set('q', params.q);
    if (params?.category) searchParams.set('category', params.category);
    const query = searchParams.toString() ? `?${searchParams.toString()}` : '';
    return request<{ materials: StudyMaterial[]; total: number }>(`/api/materials${query}`);
  },

  async getMaterial(id: string): Promise<{ material: StudyMaterial }> {
    return request<{ material: StudyMaterial }>(`/api/materials/${id}`);
  },

  async uploadMaterial(formData: FormData): Promise<{ material: StudyMaterial; message: string }> {
    return request<{ material: StudyMaterial; message: string }>('/api/materials', {
      method: 'POST',
      body: formData,
    });
  },

  async createNotesMaterial(params: {
    title: string;
    category: string;
    tags: string[];
    content: string;
  }): Promise<{ material: StudyMaterial; message: string }> {
    return request<{ material: StudyMaterial; message: string }>('/api/materials', {
      method: 'POST',
      body: JSON.stringify({ ...params, fileType: 'notes' }),
    });
  },

  async updateMaterial(
    id: string,
    params: { title?: string; category?: string; tags?: string[]; content?: string }
  ): Promise<{ material: StudyMaterial }> {
    return request<{ material: StudyMaterial }>(`/api/materials/${id}`, {
      method: 'PUT',
      body: JSON.stringify(params),
    });
  },

  async deleteMaterial(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/materials/${id}`, {
      method: 'DELETE',
    });
  },

  // AI Operations
  async generateSummary(params: {
    materialId?: string;
    title?: string;
    category?: string;
    mode: 'brief' | 'comprehensive' | 'key-points' | 'exam-prep';
    content?: string;
  }): Promise<{ summary: Summary }> {
    return request<{ summary: Summary }>('/api/ai/summarize', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async generateFlashcards(params: {
    materialId?: string;
    topic: string;
    count?: number;
    content?: string;
    deckTitle?: string;
  }): Promise<{ deck: FlashcardDeck }> {
    return request<{ deck: FlashcardDeck }>('/api/ai/flashcards', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async generateQuiz(params: {
    materialId?: string;
    topic: string;
    numQuestions?: number;
    difficulty?: 'easy' | 'medium' | 'hard';
    content?: string;
    timeLimitMinutes?: number;
  }): Promise<{ quiz: Quiz }> {
    return request<{ quiz: Quiz }>('/api/ai/quiz', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async generateStudyPlan(params: {
    title?: string;
    goal: string;
    examDate?: string;
    days: number;
    dailyHours: number;
    materialIds?: string[];
  }): Promise<{ studyPlan: StudyPlan }> {
    return request<{ studyPlan: StudyPlan }>('/api/ai/studyplan', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async askTutor(params: {
    question: string;
    materialId?: string;
    mode?: 'explain' | 'analogy' | 'practice_problem' | 'deep_dive';
  }): Promise<{
    answer: string;
    followUpQuestions: string[];
    suggestedResources: string[];
  }> {
    return request<{
      answer: string;
      followUpQuestions: string[];
      suggestedResources: string[];
    }>('/api/ai/ask', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async analyzeContent(content: string): Promise<{
    wordCount: number;
    charCount: number;
    sentenceCount: number;
    avgWordsPerSentence: number;
    estReadingTimeMinutes: number;
    difficultyRating: string;
    topKeywords: Array<{ word: string; count: number }>;
  }> {
    return request('/api/ai/analyze', {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  },

  // Summaries
  async getSummaries(): Promise<{ summaries: Summary[] }> {
    return request<{ summaries: Summary[] }>('/api/summaries');
  },

  async deleteSummary(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/summaries/${id}`, {
      method: 'DELETE',
    });
  },

  // Flashcards
  async getFlashcardDecks(): Promise<{ decks: FlashcardDeck[] }> {
    return request<{ decks: FlashcardDeck[] }>('/api/flashcards');
  },

  async reviewFlashcard(deckId: string, cardId: string, rating: 'easy' | 'medium' | 'hard'): Promise<{ card: FlashcardItem; deck: FlashcardDeck }> {
    return request<{ card: FlashcardItem; deck: FlashcardDeck }>(`/api/flashcards/${deckId}/review`, {
      method: 'POST',
      body: JSON.stringify({ cardId, rating }),
    });
  },

  async deleteDeck(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/flashcards/${id}`, {
      method: 'DELETE',
    });
  },

  // Quizzes
  async getQuizzes(): Promise<{ quizzes: Quiz[] }> {
    return request<{ quizzes: Quiz[] }>('/api/quizzes');
  },

  async getQuiz(id: string): Promise<{ quiz: Quiz }> {
    return request<{ quiz: Quiz }>(`/api/quizzes/${id}`);
  },

  async submitQuizAttempt(
    quizId: string,
    params: { userAnswers: Record<string, number>; timeSpentSeconds: number }
  ): Promise<{ attempt: QuizAttempt; quiz: Quiz }> {
    return request<{ attempt: QuizAttempt; quiz: Quiz }>(`/api/quizzes/${quizId}/attempt`, {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async getQuizAttemptsHistory(): Promise<{ attempts: QuizAttempt[] }> {
    return request<{ attempts: QuizAttempt[] }>('/api/quizzes/attempts/history');
  },

  async deleteQuiz(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/quizzes/${id}`, {
      method: 'DELETE',
    });
  },

  // Study Plans
  async getStudyPlans(): Promise<{ studyPlans: StudyPlan[] }> {
    return request<{ studyPlans: StudyPlan[] }>('/api/studyplans');
  },

  async toggleTaskCompleted(planId: string, taskId: string): Promise<{ task: any; studyPlan: StudyPlan }> {
    return request<{ task: any; studyPlan: StudyPlan }>(`/api/studyplans/${planId}/tasks/${taskId}`, {
      method: 'PUT',
    });
  },

  async deleteStudyPlan(id: string): Promise<{ success: boolean }> {
    return request<{ success: boolean }>(`/api/studyplans/${id}`, {
      method: 'DELETE',
    });
  },

  // Progress
  async getProgressDashboard(): Promise<{
    metrics: ProgressMetrics;
    categoryDistribution: Array<{ name: string; count: number }>;
    recentActivities: Array<{ id: string; type: string; title: string; timestamp: string; badge: string }>;
    recentAttempts: QuizAttempt[];
  }> {
    return request('/api/progress/dashboard');
  },

  // Notifications
  async getNotifications(): Promise<{ notifications: NotificationItem[]; unreadCount: number }> {
    return request('/api/notifications');
  },

  async markNotificationRead(id: string): Promise<{ success: boolean }> {
    return request(`/api/notifications/${id}/read`, { method: 'PUT' });
  },

  async markAllNotificationsRead(): Promise<{ success: boolean }> {
    return request('/api/notifications/read-all', { method: 'PUT' });
  },

  async deleteNotification(id: string): Promise<{ success: boolean }> {
    return request(`/api/notifications/${id}`, { method: 'DELETE' });
  },

  // Admin
  async getAdminUsers(): Promise<{ users: User[] }> {
    return request('/api/admin/users');
  },

  async updateAdminUserRole(id: string, role: 'student' | 'admin'): Promise<{ user: User }> {
    return request(`/api/admin/users/${id}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role }),
    });
  },

  async updateAdminUserStatus(id: string, status: 'active' | 'suspended'): Promise<{ user: User }> {
    return request(`/api/admin/users/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },

  async deleteAdminUser(id: string): Promise<{ success: boolean }> {
    return request(`/api/admin/users/${id}`, { method: 'DELETE' });
  },

  async getAdminAnalytics(): Promise<AdminAnalytics> {
    return request('/api/admin/analytics');
  },

  async broadcastNotification(params: { title: string; message: string; type?: string }): Promise<{ success: boolean }> {
    return request('/api/admin/broadcast', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },
};
