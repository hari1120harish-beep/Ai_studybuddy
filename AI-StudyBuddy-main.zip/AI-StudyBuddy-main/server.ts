import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import API routers
import { authRouter } from './server/routes/auth.js';
import { materialsRouter } from './server/routes/materials.js';
import { aiRouter } from './server/routes/ai.js';
import { summariesRouter } from './server/routes/summaries.js';
import { flashcardsRouter } from './server/routes/flashcards.js';
import { quizzesRouter } from './server/routes/quizzes.js';
import { studyPlansRouter } from './server/routes/studyplans.js';
import { progressRouter } from './server/routes/progress.js';
import { notificationsRouter } from './server/routes/notifications.js';
import { adminRouter } from './server/routes/admin.js';

async function createServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);
  const isProd = process.env.NODE_ENV === 'production';

  // Body parser middleware
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // API Routes
  app.use('/api/auth', authRouter);
  app.use('/api/materials', materialsRouter);
  app.use('/api/ai', aiRouter);
  app.use('/api/summaries', summariesRouter);
  app.use('/api/flashcards', flashcardsRouter);
  app.use('/api/quizzes', quizzesRouter);
  app.use('/api/studyplans', studyPlansRouter);
  app.use('/api/progress', progressRouter);
  app.use('/api/notifications', notificationsRouter);
  app.use('/api/admin', adminRouter);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'AI StudyBuddy API',
      timestamp: new Date().toISOString(),
      geminiConfigured: !!process.env.GEMINI_API_KEY,
    });
  });

  // Global API Error Handler
  app.use('/api', (err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('Unhandled API error:', err);
    res.status(err.status || 500).json({
      error: err.message || 'Internal server error occurred',
    });
  });

  // Vite middleware in dev or static files in prod
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 AI StudyBuddy server running on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
