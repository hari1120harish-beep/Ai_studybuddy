import { GoogleGenAI, Type } from '@google/genai';
import { dbInstance } from './db.js';

const apiKey = process.env.GEMINI_API_KEY;

export const ai = apiKey
  ? new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

export function recordAiUsage(userId: string, userName: string, action: any, tokens: number) {
  const log = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    userName,
    action,
    promptTokensEstimate: tokens,
    model: 'gemini-3.8-flash',
    timestamp: new Date().toISOString(),
  };
  dbInstance.db.aiUsageLogs.unshift(log);
  dbInstance.save();
}

/**
 * Generate comprehensive study summary
 */
export async function generateSummaryAI(params: {
  title: string;
  category: string;
  mode: 'brief' | 'comprehensive' | 'key-points' | 'exam-prep';
  content: string;
  userId: string;
  userName: string;
}) {
  const { title, category, mode, content, userId, userName } = params;
  recordAiUsage(userId, userName, 'summary', Math.ceil(content.length / 4));

  if (!ai) {
    return generateFallbackSummary(title, category, mode, content);
  }

  const prompt = `You are an elite educational AI tutor and learning scientist.
Please generate an outstanding study summary for the following learning material.

Title: "${title}"
Subject/Category: "${category}"
Summary Mode: "${mode}"

Content:
"""
${content.slice(0, 15000)}
"""

Return a valid JSON object matching this schema:
{
  "executiveSummary": "2-4 paragraphs synthesizing the core concepts with high clarity and depth",
  "keyConcepts": [
    { "term": "Concept Name", "explanation": "Clear, precise explanation and relevance" }
  ],
  "takeaways": [
    "3 to 6 high-impact takeaway bullet points"
  ],
  "mindmapOutline": [
    "Hierarchical mindmap nodes, e.g. Topic -> Subtopic -> Detail"
  ],
  "suggestedQuestions": [
    "2 to 4 thought-provoking self-test questions to evaluate comprehension"
  ]
}

Ensure the output is strictly valid JSON without markdown wrapping.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);
    return {
      executiveSummary: parsed.executiveSummary || 'Summary generated.',
      keyConcepts: Array.isArray(parsed.keyConcepts) ? parsed.keyConcepts : [],
      takeaways: Array.isArray(parsed.takeaways) ? parsed.takeaways : [],
      mindmapOutline: Array.isArray(parsed.mindmapOutline) ? parsed.mindmapOutline : [],
      suggestedQuestions: Array.isArray(parsed.suggestedQuestions) ? parsed.suggestedQuestions : [],
    };
  } catch (error) {
    console.error('Gemini generateSummary error, using smart fallback:', error);
    return generateFallbackSummary(title, category, mode, content);
  }
}

/**
 * Generate flashcards deck
 */
export async function generateFlashcardsAI(params: {
  topic: string;
  content: string;
  count?: number;
  userId: string;
  userName: string;
}) {
  const { topic, content, count = 8, userId, userName } = params;
  recordAiUsage(userId, userName, 'flashcards', Math.ceil(content.length / 4));

  if (!ai) {
    return generateFallbackFlashcards(topic, content, count);
  }

  const prompt = `You are a cognitive science learning expert. Create a deck of ${count} high-quality flashcards for active recall and spaced repetition based on this material:

Topic: "${topic}"
Content:
"""
${content.slice(0, 15000)}
"""

Return a valid JSON array of objects:
[
  {
    "front": "Clear, specific question, formula, or term prompting active recall",
    "back": "Accurate, concise, and structured answer",
    "hint": "Brief subtle hint or clue",
    "topic": "Specific sub-topic or theme"
  }
]

Ensure output is strictly valid JSON with no markdown wrapping.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '[]';
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed.map((c, i) => ({
        id: `card_${Date.now()}_${i}`,
        front: c.front || 'Concept Question',
        back: c.back || 'Concept Answer',
        hint: c.hint || '',
        topic: c.topic || topic,
        masteryLevel: 'new' as const,
        reviewCount: 0,
      }));
    }
    return generateFallbackFlashcards(topic, content, count);
  } catch (error) {
    console.error('Gemini generateFlashcards error, using smart fallback:', error);
    return generateFallbackFlashcards(topic, content, count);
  }
}

/**
 * Generate interactive practice quiz
 */
export async function generateQuizAI(params: {
  topic: string;
  content: string;
  numQuestions?: number;
  difficulty?: 'easy' | 'medium' | 'hard' | 'mixed';
  userId: string;
  userName: string;
}) {
  const { topic, content, numQuestions = 5, difficulty = 'medium', userId, userName } = params;
  recordAiUsage(userId, userName, 'quiz', Math.ceil(content.length / 4));

  if (!ai) {
    return generateFallbackQuiz(topic, content, numQuestions);
  }

  const prompt = `You are an academic exam creator. Generate a rigorous ${numQuestions}-question multiple choice practice quiz on "${topic}".
Difficulty level: ${difficulty}.

Study Content:
"""
${content.slice(0, 15000)}
"""

Return a valid JSON object matching this schema:
{
  "title": "Clear exam title for the quiz",
  "questions": [
    {
      "question": "Clear, unambiguous question stem",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0, // 0-based integer index of correct option (0, 1, 2, or 3)
      "explanation": "Detailed explanation of why the correct option is right and others are incorrect",
      "difficulty": "easy" // or "medium" or "hard"
    }
  ]
}

Ensure the output is strictly valid JSON without markdown wrapping.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);
    if (parsed.questions && Array.isArray(parsed.questions)) {
      return {
        title: parsed.title || `${topic} Practice Quiz`,
        questions: parsed.questions.map((q: any, i: number) => ({
          id: `q_${Date.now()}_${i}`,
          question: q.question,
          options: Array.isArray(q.options) && q.options.length === 4 ? q.options : ['A', 'B', 'C', 'D'],
          correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
          explanation: q.explanation || 'No explanation provided.',
          difficulty: q.difficulty || 'medium',
        })),
      };
    }
    return generateFallbackQuiz(topic, content, numQuestions);
  } catch (error) {
    console.error('Gemini generateQuiz error, using fallback:', error);
    return generateFallbackQuiz(topic, content, numQuestions);
  }
}

/**
 * Generate personalized study plan
 */
export async function generateStudyPlanAI(params: {
  title: string;
  goal: string;
  examDate?: string;
  days: number;
  dailyHours: number;
  materialsContext?: string;
  userId: string;
  userName: string;
}) {
  const { title, goal, examDate, days, dailyHours, materialsContext = '', userId, userName } = params;
  recordAiUsage(userId, userName, 'studyplan', 600);

  if (!ai) {
    return generateFallbackStudyPlan(title, goal, days, dailyHours);
  }

  const prompt = `You are an expert academic advisor and learning strategist.
Create a structured, highly actionable ${days}-day study plan.
Goal: "${goal}"
Study Hours Available per Day: ${dailyHours} hours.
Target Exam Date: ${examDate || 'In ' + days + ' days'}.
Additional Context/Materials:
"""
${materialsContext.slice(0, 8000)}
"""

Return a valid JSON object:
{
  "tasks": [
    {
      "day": 1,
      "dayName": "Day 1 - Core Foundations",
      "topic": "Specific Topic Name",
      "activity": "Concrete actionable learning activity, problem set, or review",
      "durationMinutes": 90,
      "priority": "high", // "high" | "medium" | "low"
      "resources": ["Key resource or chapter 1"]
    }
  ]
}

Ensure each day from 1 to ${days} has dedicated focused milestones. Output strictly valid JSON without markdown wrapping.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);
    if (parsed.tasks && Array.isArray(parsed.tasks)) {
      return parsed.tasks.map((t: any, i: number) => ({
        id: `task_${Date.now()}_${i}`,
        day: t.day || i + 1,
        dayName: t.dayName || `Day ${i + 1}`,
        topic: t.topic || 'Core Subject Review',
        activity: t.activity || 'Review notes and practice flashcards.',
        durationMinutes: t.durationMinutes || dailyHours * 60,
        completed: false,
        priority: t.priority || 'medium',
        resources: Array.isArray(t.resources) ? t.resources : [],
      }));
    }
    return generateFallbackStudyPlan(title, goal, days, dailyHours);
  } catch (error) {
    console.error('Gemini generateStudyPlan error, using fallback:', error);
    return generateFallbackStudyPlan(title, goal, days, dailyHours);
  }
}

/**
 * Ask AI StudyBuddy / Explain topic with analogies & Q&A
 */
export async function askStudyBuddyAI(params: {
  question: string;
  materialsContext?: string;
  conversationHistory?: Array<{ role: 'user' | 'assistant'; text: string }>;
  mode?: 'explain' | 'analogy' | 'practice_problem' | 'deep_dive';
  userId: string;
  userName: string;
}) {
  const { question, materialsContext = '', conversationHistory = [], mode = 'explain', userId, userName } = params;
  recordAiUsage(userId, userName, 'explanation', Math.ceil(question.length / 4) + 200);

  if (!ai) {
    return {
      answer: `Here is a structured explanation for: "${question}"\n\n1. Core Principle: Focus on the foundational concepts outlined in your uploaded materials.\n2. Application: Break down the problem step-by-step.\n3. Pro-Tip: Practice retrieval with our flashcards tool to cement this in long-term memory!`,
      followUpQuestions: [
        'How does this relate to other topics in your materials?',
        'Would you like a practice quiz question on this?'
      ],
      suggestedResources: ['Review uploaded study materials on this topic'],
    };
  }

  const prompt = `You are "AI StudyBuddy", a supportive, brilliant, and pedagogical learning tutor.
Mode: "${mode}"

Student Question / Request:
"${question}"

Relevant Uploaded Student Study Materials Context:
"""
${materialsContext.slice(0, 10000)}
"""

Provide a lucid, pedagogically sound response. Format with clear headings, bold key concepts, and step-by-step clarity.
Also provide 2-3 follow up prompts to deepen understanding.

Return a JSON object:
{
  "answer": "Detailed markdown explanation with bold terms, intuitive analogies, and key formulas if applicable",
  "followUpQuestions": ["Question 1", "Question 2", "Question 3"],
  "suggestedResources": ["Resource or topic to review"]
}
Strictly valid JSON with no markdown wrapping.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);
    return {
      answer: parsed.answer || 'Explanation generated.',
      followUpQuestions: Array.isArray(parsed.followUpQuestions) ? parsed.followUpQuestions : [],
      suggestedResources: Array.isArray(parsed.suggestedResources) ? parsed.suggestedResources : [],
    };
  } catch (error) {
    console.error('Gemini askStudyBuddy error:', error);
    return {
      answer: `Explanation for "${question}":\n\nKey Concept Breakdown:\n• Analyze the core definitions and mechanisms.\n• Relate this concept back to your foundational notes.\n• Test yourself with active recall quizzes!`,
      followUpQuestions: ['Can you provide an intuitive real-world analogy?', 'Generate a multiple-choice question on this'],
      suggestedResources: ['Review module notes'],
    };
  }
}

/**
 * Fallbacks
 */
function generateFallbackSummary(title: string, category: string, mode: string, content: string) {
  const words = content.split(/\s+/).slice(0, 120).join(' ');
  return {
    executiveSummary: `This summary provides an organized synthesis of "${title}" (${category}). The material covers fundamental concepts and key principles necessary for comprehensive mastery.\n\nContext excerpt: ${words}...`,
    keyConcepts: [
      { term: 'Foundational Principles', explanation: 'The baseline definitions and axioms required to understand the core subject.' },
      { term: 'Operational Dynamics', explanation: 'The sequential procedures and interactions governing how components work together.' },
      { term: 'Key Applications', explanation: 'Practical implementations and analytical methodologies utilized in this domain.' }
    ],
    takeaways: [
      'Mastering the basic vocabulary and definitions is essential before tackling advanced mechanics.',
      'Active synthesis and regular problem solving dramatically improve long-term retention.',
      'Systematic review using spaced intervals prevents the forgetting curve.'
    ],
    mindmapOutline: [
      `${title} -> Core Concepts -> Theoretical Axioms`,
      `${title} -> Methodologies -> Practical Applications`,
      `${title} -> Review & Verification -> Self-Testing`
    ],
    suggestedQuestions: [
      `What are the primary factors that influence outcomes in ${title}?`,
      `How would you explain the central thesis to a fellow student in 2 minutes?`
    ],
  };
}

function generateFallbackFlashcards(topic: string, content: string, count: number) {
  return [
    {
      id: `card_${Date.now()}_1`,
      front: `What is the core definition or objective of ${topic}?`,
      back: `It represents the structured framework and principles covered in the material: "${content.slice(0, 120)}..."`,
      hint: 'Think about the primary purpose of the subject.',
      topic: topic,
      masteryLevel: 'new' as const,
      reviewCount: 0,
    },
    {
      id: `card_${Date.now()}_2`,
      front: `What are the primary mechanisms or components in ${topic}?`,
      back: `The fundamental building blocks that coordinate together to accomplish the system's goals.`,
      hint: 'Key internal elements.',
      topic: topic,
      masteryLevel: 'new' as const,
      reviewCount: 0,
    },
    {
      id: `card_${Date.now()}_3`,
      front: `How does one test or verify understanding in ${topic}?`,
      back: `Through active recall, step-by-step problem sets, and diagnostic quizzes.`,
      hint: 'Learning methodology.',
      topic: topic,
      masteryLevel: 'new' as const,
      reviewCount: 0,
    },
  ];
}

function generateFallbackQuiz(topic: string, content: string, count: number) {
  return {
    title: `${topic} Diagnostic Quiz`,
    questions: [
      {
        id: `q_${Date.now()}_1`,
        question: `Which statement best describes the primary focus of "${topic}"?`,
        options: [
          'It systematically develops foundational concepts and applied mechanisms',
          'It is purely an arbitrary historic taxonomy without modern use',
          'It replaces the need for conceptual analysis',
          'It applies only to theoretical physics'
        ],
        correctAnswer: 0,
        explanation: 'The material provides a structured analytical framework for understanding the core principles.',
        difficulty: 'easy' as const,
      },
      {
        id: `q_${Date.now()}_2`,
        question: 'What is the most effective approach to mastering this subject according to cognitive science?',
        options: [
          'Passive rereading 5 minutes before the exam',
          'Active recall, spaced repetition flashcards, and conceptual self-testing',
          'Memorizing raw formulas without understanding their derivations',
          'Highlighting entire paragraphs in neon colors'
        ],
        correctAnswer: 1,
        explanation: 'Active recall and spaced repetition are experimentally proven to yield the highest memory retention and conceptual transfer.',
        difficulty: 'medium' as const,
      }
    ],
  };
}

function generateFallbackStudyPlan(title: string, goal: string, days: number, dailyHours: number) {
  const tasks = [];
  for (let d = 1; d <= days; d++) {
    tasks.push({
      id: `task_${Date.now()}_${d}`,
      day: d,
      dayName: `Day ${d} - ${d === 1 ? 'Foundations' : d === days ? 'Final Synthesis & Mock' : 'Core Deep Dive ' + (d - 1)}`,
      topic: d === 1 ? 'Foundations & Vocabulary' : d === days ? 'Full Mock Exam & Review' : `Advanced Module ${d}`,
      activity: d === days ? 'Complete practice quiz and review weak cards.' : 'Read notes, extract key terms, and review flashcards.',
      durationMinutes: dailyHours * 60,
      completed: false,
      priority: d === 1 || d === days ? 'high' as const : 'medium' as const,
      resources: ['StudyBuddy Material Library'],
    });
  }
  return tasks;
}
