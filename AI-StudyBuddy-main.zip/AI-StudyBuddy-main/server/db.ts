import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'student' | 'admin';
  avatar?: string;
  targetExam?: string;
  learningGoal?: string;
  studyHoursPerDay?: number;
  createdAt: string;
  status: 'active' | 'suspended';
}

export interface StudyMaterial {
  id: string;
  userId: string;
  title: string;
  category: string;
  tags: string[];
  fileType: 'pdf' | 'doc' | 'txt' | 'notes';
  fileName?: string;
  fileSize?: string;
  content: string;
  wordCount: number;
  readingTimeMin: number;
  uploadedAt: string;
  updatedAt: string;
}

export interface Summary {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  category: string;
  mode: 'brief' | 'comprehensive' | 'key-points' | 'exam-prep';
  executiveSummary: string;
  keyConcepts: Array<{ term: string; explanation: string }>;
  takeaways: string[];
  mindmapOutline?: string[];
  suggestedQuestions?: string[];
  createdAt: string;
}

export interface FlashcardItem {
  id: string;
  front: string;
  back: string;
  hint?: string;
  topic?: string;
  masteryLevel: 'new' | 'learning' | 'mastered';
  reviewCount: number;
  lastReviewed?: string;
}

export interface FlashcardDeck {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  description: string;
  category: string;
  cards: FlashcardItem[];
  createdAt: string;
  updatedAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // 0-based index
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Quiz {
  id: string;
  userId: string;
  materialId?: string;
  title: string;
  topic: string;
  questions: QuizQuestion[];
  timeLimitMinutes: number;
  createdAt: string;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  quizId: string;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  userAnswers: Record<string, number>;
  timeSpentSeconds: number;
  completedAt: string;
}

export interface StudyPlanTask {
  id: string;
  day: number;
  dayName: string;
  topic: string;
  activity: string;
  durationMinutes: number;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  resources?: string[];
}

export interface StudyPlan {
  id: string;
  userId: string;
  title: string;
  goal: string;
  examDate?: string;
  totalDays: number;
  dailyHours: number;
  tasks: StudyPlanTask[];
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string; // or 'all' for broadcast
  title: string;
  message: string;
  type: 'info' | 'success' | 'alert' | 'streak';
  read: boolean;
  createdAt: string;
}

export interface AIUsageLog {
  id: string;
  userId: string;
  userName: string;
  action: 'summary' | 'flashcards' | 'quiz' | 'studyplan' | 'explanation' | 'analysis';
  promptTokensEstimate: number;
  model: string;
  timestamp: string;
}

export interface DatabaseSchema {
  users: User[];
  materials: StudyMaterial[];
  summaries: Summary[];
  flashcardDecks: FlashcardDeck[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  studyPlans: StudyPlan[];
  notifications: NotificationItem[];
  aiUsageLogs: AIUsageLog[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Default initial seed
const defaultPasswordHash = bcrypt.hashSync('password123', 10);

const defaultDb: DatabaseSchema = {
  users: [
    {
      id: 'usr_student_1',
      name: 'Alex Rivera',
      email: 'student@studybuddy.ai',
      passwordHash: defaultPasswordHash,
      role: 'student',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
      targetExam: 'GRE Computer Science & AI Systems',
      learningGoal: 'Master Deep Learning, Operating Systems & Algorithms',
      studyHoursPerDay: 3,
      createdAt: '2026-09-01T08:00:00Z',
      status: 'active',
    },
    {
      id: 'usr_admin_1',
      name: 'Dr. Sarah Mitchell',
      email: 'admin@studybuddy.ai',
      passwordHash: defaultPasswordHash,
      role: 'admin',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80',
      targetExam: 'Faculty Supervisor',
      learningGoal: 'Platform Curriculum Management & Quality Oversight',
      studyHoursPerDay: 4,
      createdAt: '2026-08-15T09:30:00Z',
      status: 'active',
    },
  ],
  materials: [
    {
      id: 'mat_1',
      userId: 'usr_student_1',
      title: 'Neural Networks & Deep Learning Foundations',
      category: 'Computer Science',
      tags: ['AI', 'Deep Learning', 'Calculus', 'Backpropagation'],
      fileType: 'notes',
      fileName: 'dl_foundations_notes.md',
      fileSize: '14.2 KB',
      content: `Neural networks are computing systems inspired by the biological neural networks that constitute animal brains. An Artificial Neural Network (ANN) is composed of connected units or nodes called artificial neurons.

1. Architecture and Perceptron:
Each connection can transmit a signal to other neurons. An artificial neuron receives signals, processes them, and can signal neurons connected to it. The "signal" at a connection is a real number, and the output of each neuron is computed by some non-linear function of the sum of its inputs (Activation Functions such as ReLU, Sigmoid, and Tanh).

2. Forward Propagation and Loss Functions:
During forward propagation, input feature vector X passes through weights W and biases b across hidden layers:
Z^[l] = W^[l] * A^[l-1] + b^[l]
A^[l] = g(Z^[l])
The discrepancy between predicted output y_hat and ground truth y is quantified using a Loss Function (e.g., Mean Squared Error for regression, Binary Cross-Entropy for binary classification, or Softmax Categorical Cross-Entropy for multi-class classification).

3. Backpropagation and Optimization:
Optimization uses Gradient Descent. The chain rule of calculus is recursively computed to calculate partial derivatives of the loss with respect to every parameter (dW and db). Popular modern optimizers include Adam (Adaptive Moment Estimation), RMSprop, and SGD with Momentum.

4. Regularization Techniques:
To prevent overfitting on the training distribution, researchers employ Dropout (randomly zeroing neuron activations during training), L2 Weight Decay, Batch Normalization, and Data Augmentation.`,
      wordCount: 236,
      readingTimeMin: 2,
      uploadedAt: '2026-09-20T10:15:00Z',
      updatedAt: '2026-09-20T10:15:00Z',
    },
    {
      id: 'mat_2',
      userId: 'usr_student_1',
      title: 'Operating Systems: Virtual Memory & Paging',
      category: 'Computer Science',
      tags: ['OS', 'Virtual Memory', 'Paging', 'TLB'],
      fileType: 'txt',
      fileName: 'operating_systems_virtual_memory.txt',
      fileSize: '8.4 KB',
      content: `Virtual Memory is a memory management capability of an operating system that uses hardware and software to allow a computer to compensate for physical memory shortages by temporarily transferring data from random access memory (RAM) to disk storage.

Key Mechanisms:
- Paging: The process of dividing virtual address space into fixed-size units called pages (typically 4KB), and physical memory into identical frames.
- Page Table: A data structure used by a virtual memory system in a computer operating system to store the mapping between virtual addresses and physical addresses.
- Translation Lookaside Buffer (TLB): A hardware cache of recent virtual-to-physical address translations inside the Memory Management Unit (MMU). A TLB miss forces a page table walk in main memory.
- Page Fault: An interrupt generated when a program attempts to access a page that is mapped in the address space, but not loaded in physical RAM. The OS fetches the required page from the swap space on disk.
- Page Replacement Algorithms: LRU (Least Recently Used), FIFO, Optimal (MIN), and the Clock Algorithm.`,
      wordCount: 168,
      readingTimeMin: 1,
      uploadedAt: '2026-09-22T14:40:00Z',
      updatedAt: '2026-09-22T14:40:00Z',
    },
  ],
  summaries: [
    {
      id: 'sum_1',
      userId: 'usr_student_1',
      materialId: 'mat_1',
      title: 'Deep Learning Core Principles Summary',
      category: 'Computer Science',
      mode: 'comprehensive',
      executiveSummary: 'This document provides a concise mathematical and conceptual synthesis of Artificial Neural Networks, focusing on forward signal propagation, loss quantification, backward gradient computation via the chain rule, and modern regularization strategies to guarantee generalization.',
      keyConcepts: [
        { term: 'Forward Propagation', explanation: 'Sequential linear combination of weights and inputs followed by non-linear activation functions.' },
        { term: 'Backpropagation', explanation: 'Application of the differential chain rule to calculate loss gradients across network weights.' },
        { term: 'Adam Optimizer', explanation: 'Adaptive learning rate algorithm combining momentum and root-mean-square gradient scaling.' },
        { term: 'Batch Normalization', explanation: 'Normalizes layer inputs across mini-batches to accelerate training stability.' }
      ],
      takeaways: [
        'Non-linear activation functions are necessary to enable networks to approximate non-linear functions.',
        'Loss functions quantify prediction divergence; Cross-Entropy is standard for classification.',
        'Regularization techniques like Dropout and L2 weight decay reduce overfitting risks.'
      ],
      mindmapOutline: [
        'Neural Architecture -> Perceptrons -> Activation Functions (ReLU, Softmax)',
        'Learning Process -> Forward Pass -> Loss Function -> Backprop -> Gradient Descent',
        'Generalization -> Overfitting Mitigation -> Dropout & Batch Normalization'
      ],
      suggestedQuestions: [
        'Why would a neural network collapse into a single linear transformation without non-linear activations?',
        'How does Adam adapt individual parameter learning rates dynamically?'
      ],
      createdAt: '2026-09-20T10:20:00Z',
    },
  ],
  flashcardDecks: [
    {
      id: 'deck_1',
      userId: 'usr_student_1',
      materialId: 'mat_1',
      title: 'Neural Networks Fundamentals',
      description: 'Key definitions and mathematical building blocks of deep neural architectures.',
      category: 'Computer Science',
      cards: [
        {
          id: 'card_1_1',
          front: 'What is the purpose of an Activation Function in a neuron?',
          back: 'To introduce non-linearity into the network, allowing it to learn complex boundaries and represent non-linear relationships.',
          hint: 'Think about linear algebra transformations.',
          topic: 'Activations',
          masteryLevel: 'mastered',
          reviewCount: 4,
          lastReviewed: '2026-09-25T11:00:00Z',
        },
        {
          id: 'card_1_2',
          front: 'How does Backpropagation calculate gradients?',
          back: 'It applies the differential chain rule backward from the loss function through each layer to compute partial derivatives dW and db.',
          hint: 'Calculus derivative composition.',
          topic: 'Optimization',
          masteryLevel: 'learning',
          reviewCount: 2,
          lastReviewed: '2026-09-26T09:15:00Z',
        },
        {
          id: 'card_1_3',
          front: 'What does Dropout do during training?',
          back: 'It randomly sets a fraction of neuron outputs to zero at each forward pass, preventing co-adaptation and reducing overfitting.',
          hint: 'Random deactivation technique.',
          topic: 'Regularization',
          masteryLevel: 'new',
          reviewCount: 0,
        },
        {
          id: 'card_1_4',
          front: 'What is the difference between Mean Squared Error and Cross-Entropy?',
          back: 'MSE is primarily used for continuous regression targets, while Cross-Entropy measures relative probability divergence in classification.',
          hint: 'Regression vs classification loss.',
          topic: 'Loss Functions',
          masteryLevel: 'learning',
          reviewCount: 1,
          lastReviewed: '2026-09-24T16:20:00Z',
        }
      ],
      createdAt: '2026-09-20T10:30:00Z',
      updatedAt: '2026-09-26T09:15:00Z',
    }
  ],
  quizzes: [
    {
      id: 'quiz_1',
      userId: 'usr_student_1',
      materialId: 'mat_1',
      title: 'Deep Learning Mastery Check',
      topic: 'Neural Networks & Optimization',
      timeLimitMinutes: 10,
      questions: [
        {
          id: 'q_1',
          question: 'If all activation functions in a 5-layer neural network are linear, what is the effective model equivalent to?',
          options: [
            'A convolutional neural network',
            'A single linear model (W_total * x + b_total)',
            'An unlearnable random projection',
            'A polynomial regression of degree 5'
          ],
          correctAnswer: 1,
          explanation: 'The composition of linear functions is always another linear function. Without non-linear activations, multi-layer depth provides no additional representational power.',
          difficulty: 'medium'
        },
        {
          id: 'q_2',
          question: 'Which optimizer dynamically maintains both an exponentially decaying average of past gradients and squared gradients?',
          options: [
            'Standard SGD',
            'RMSprop',
            'AdaGrad',
            'Adam'
          ],
          correctAnswer: 3,
          explanation: 'Adam (Adaptive Moment Estimation) tracks first-order momentum (mean) and second-order momentum (uncentered variance) of gradients.',
          difficulty: 'easy'
        },
        {
          id: 'q_3',
          question: 'What happens when a high dropout rate (e.g., 0.8) is applied during testing/inference?',
          options: [
            'The network outputs become deterministic and faster',
            'Dropout is turned off during testing; weights are typically scaled or activations left active',
            'Overfitting occurs at test time',
            'The test accuracy doubles'
          ],
          correctAnswer: 1,
          explanation: 'Dropout is exclusively an active training regularization technique. At test time, all units remain active with expected weights applied.',
          difficulty: 'medium'
        }
      ],
      createdAt: '2026-09-20T11:00:00Z',
    }
  ],
  quizAttempts: [
    {
      id: 'att_1',
      userId: 'usr_student_1',
      quizId: 'quiz_1',
      quizTitle: 'Deep Learning Mastery Check',
      score: 3,
      totalQuestions: 3,
      percentage: 100,
      userAnswers: { 'q_1': 1, 'q_2': 3, 'q_3': 1 },
      timeSpentSeconds: 145,
      completedAt: '2026-09-21T15:20:00Z',
    }
  ],
  studyPlans: [
    {
      id: 'plan_1',
      userId: 'usr_student_1',
      title: '7-Day AI & Systems Sprint',
      goal: 'Prepare for Machine Learning Systems midterm examination',
      examDate: '2026-10-05',
      totalDays: 7,
      dailyHours: 3,
      tasks: [
        {
          id: 'task_1',
          day: 1,
          dayName: 'Day 1 - Foundations',
          topic: 'Linear Algebra & Neural Feed-Forward',
          activity: 'Review Matrix multiplications, vector calculus, and implement a 2-layer MLP in NumPy.',
          durationMinutes: 90,
          completed: true,
          priority: 'high',
          resources: ['Deep Learning Notes Chapter 1', 'NumPy Vectors Guide']
        },
        {
          id: 'task_2',
          day: 2,
          dayName: 'Day 2 - Backpropagation',
          topic: 'Computational Graphs & Chain Rule',
          activity: 'Derive analytic gradients for Softmax + Cross Entropy loss; solve 3 manual backprop exercises.',
          durationMinutes: 90,
          completed: true,
          priority: 'high',
          resources: ['Backprop Cheatsheet']
        },
        {
          id: 'task_3',
          day: 3,
          dayName: 'Day 3 - Optimization',
          topic: 'SGD, Momentum, and Adam',
          activity: 'Compare learning trajectories and learning rate decay strategies.',
          durationMinutes: 90,
          completed: false,
          priority: 'medium',
          resources: ['Optimizer Visualizer']
        },
        {
          id: 'task_4',
          day: 4,
          dayName: 'Day 4 - Regularization',
          topic: 'Dropout, Batch Normalization & L2 Decay',
          activity: 'Run flashcards deck and complete interactive quiz on Regularization concepts.',
          durationMinutes: 90,
          completed: false,
          priority: 'medium'
        },
        {
          id: 'task_5',
          day: 5,
          dayName: 'Day 5 - Virtual Memory',
          topic: 'Page Tables, MMU & TLB Caches',
          activity: 'Read OS chapter on paging and calculate effective memory access times under TLB hit rates.',
          durationMinutes: 120,
          completed: false,
          priority: 'high'
        },
        {
          id: 'task_6',
          day: 6,
          dayName: 'Day 6 - Systems Integration',
          topic: 'Paging algorithms & GPU memory paging',
          activity: 'Analyze unified memory architecture and practice page replacement problems (LRU vs Clock).',
          durationMinutes: 90,
          completed: false,
          priority: 'medium'
        },
        {
          id: 'task_7',
          day: 7,
          dayName: 'Day 7 - Final Synthesis',
          topic: 'Full Mock Exam & Weak-Area Remediation',
          activity: 'Take a comprehensive 20-question randomized mock test and review flagged AI flashcards.',
          durationMinutes: 120,
          completed: false,
          priority: 'high'
        }
      ],
      createdAt: '2026-09-21T09:00:00Z',
    }
  ],
  notifications: [
    {
      id: 'notif_1',
      userId: 'usr_student_1',
      title: 'Quiz Mastered!',
      message: 'You scored 100% on Deep Learning Mastery Check! Great job retaining key concepts.',
      type: 'success',
      read: true,
      createdAt: '2026-09-21T15:21:00Z',
    },
    {
      id: 'notif_2',
      userId: 'usr_student_1',
      title: 'Daily Study Streak',
      message: 'You have a 5-day active study streak! Keep up the momentum for your midterm.',
      type: 'streak',
      read: false,
      createdAt: '2026-09-26T08:00:00Z',
    },
    {
      id: 'notif_3',
      userId: 'usr_student_1',
      title: 'Study Plan Reminder',
      message: 'Day 3 task "SGD, Momentum, and Adam" is scheduled for today.',
      type: 'info',
      read: false,
      createdAt: '2026-09-27T07:30:00Z',
    },
    {
      id: 'notif_admin_1',
      userId: 'usr_admin_1',
      title: 'System Operational',
      message: 'AI StudyBuddy platform v2.4 initialized with active Gemini 3.8 Flash engine.',
      type: 'info',
      read: true,
      createdAt: '2026-09-20T00:00:00Z',
    }
  ],
  aiUsageLogs: [
    {
      id: 'log_1',
      userId: 'usr_student_1',
      userName: 'Alex Rivera',
      action: 'summary',
      promptTokensEstimate: 450,
      model: 'gemini-3.8-flash',
      timestamp: '2026-09-20T10:20:00Z',
    },
    {
      id: 'log_2',
      userId: 'usr_student_1',
      userName: 'Alex Rivera',
      action: 'flashcards',
      promptTokensEstimate: 620,
      model: 'gemini-3.8-flash',
      timestamp: '2026-09-20T10:30:00Z',
    },
    {
      id: 'log_3',
      userId: 'usr_student_1',
      userName: 'Alex Rivera',
      action: 'quiz',
      promptTokensEstimate: 510,
      model: 'gemini-3.8-flash',
      timestamp: '2026-09-20T11:00:00Z',
    },
    {
      id: 'log_4',
      userId: 'usr_student_1',
      userName: 'Alex Rivera',
      action: 'studyplan',
      promptTokensEstimate: 780,
      model: 'gemini-3.8-flash',
      timestamp: '2026-09-21T09:00:00Z',
    },
  ]
};

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Failed to load db file, seeding fresh defaults:', e);
    }
    this.save(defaultDb);
    return defaultDb;
  }

  public save(dataToSave?: DatabaseSchema) {
    if (dataToSave) {
      this.data = dataToSave;
    }
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving db file:', e);
    }
  }

  public get db(): DatabaseSchema {
    return this.data;
  }
}

export const dbInstance = new Database();
