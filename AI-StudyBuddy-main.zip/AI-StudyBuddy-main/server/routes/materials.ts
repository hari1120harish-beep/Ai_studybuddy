import { Router, Response } from 'express';
import multer from 'multer';
import { dbInstance, StudyMaterial } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const materialsRouter = Router();

// Configure multer storage in memory
const upload = multer({
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

// GET /api/materials - List user's materials with search and category filters
materialsRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const { q, category, tag } = req.query;

  let list = dbInstance.db.materials.filter((m) => m.userId === userId);

  if (q && typeof q === 'string') {
    const query = q.toLowerCase();
    list = list.filter(
      (m) =>
        m.title.toLowerCase().includes(query) ||
        m.category.toLowerCase().includes(query) ||
        m.tags.some((t) => t.toLowerCase().includes(query)) ||
        m.content.toLowerCase().includes(query)
    );
  }

  if (category && typeof category === 'string' && category !== 'All') {
    list = list.filter((m) => m.category.toLowerCase() === category.toLowerCase());
  }

  if (tag && typeof tag === 'string') {
    list = list.filter((m) => m.tags.includes(tag));
  }

  // Sort by uploadedAt desc
  list.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());

  return res.json({ materials: list, total: list.length });
});

// GET /api/materials/:id - Single material
materialsRouter.get('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const material = dbInstance.db.materials.find(
    (m) => m.id === req.params.id && (m.userId === userId || req.user!.role === 'admin')
  );

  if (!material) {
    return res.status(404).json({ error: 'Study material not found.' });
  }

  return res.json({ material });
});

// POST /api/materials - Upload file or create direct notes
materialsRouter.post(
  '/',
  authenticateToken,
  upload.single('file'),
  (req: AuthRequest, res: Response) => {
    try {
      const userId = req.user!.id;
      let { title, category = 'General', tags = '', content, fileType = 'notes' } = req.body;

      let extractedContent = content || '';
      let fileName = '';
      let fileSize = '0 KB';

      if (req.file) {
        fileName = req.file.originalname;
        const sizeBytes = req.file.size;
        fileSize = sizeBytes > 1024 * 1024
          ? `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB`
          : `${(sizeBytes / 1024).toFixed(1)} KB`;

        const ext = fileName.split('.').pop()?.toLowerCase();
        if (ext === 'pdf') fileType = 'pdf';
        else if (ext === 'doc' || ext === 'docx') fileType = 'doc';
        else if (ext === 'txt') fileType = 'txt';

        // Read text content from buffer
        if (!extractedContent) {
          extractedContent = req.file.buffer.toString('utf-8');
        }
        if (!title) {
          title = fileName.replace(/\.[^/.]+$/, '');
        }
      }

      if (!title || !title.trim()) {
        return res.status(400).json({ error: 'Document title is required.' });
      }

      if (!extractedContent || !extractedContent.trim()) {
        return res.status(400).json({ error: 'Document content cannot be empty.' });
      }

      const parsedTags = Array.isArray(tags)
        ? tags
        : typeof tags === 'string'
        ? tags.split(',').map((t) => t.trim()).filter(Boolean)
        : [];

      const words = extractedContent.trim().split(/\s+/).length;
      const readingTime = Math.max(1, Math.ceil(words / 200));

      const newMaterial: StudyMaterial = {
        id: `mat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId,
        title: title.trim(),
        category: category.trim() || 'General',
        tags: parsedTags,
        fileType: fileType as any,
        fileName: fileName || `${title.replace(/\s+/g, '_')}.txt`,
        fileSize,
        content: extractedContent.trim(),
        wordCount: words,
        readingTimeMin: readingTime,
        uploadedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      dbInstance.db.materials.unshift(newMaterial);
      dbInstance.save();

      return res.status(201).json({ material: newMaterial, message: 'Material uploaded successfully.' });
    } catch (error) {
      console.error('Error uploading material:', error);
      return res.status(500).json({ error: 'Failed to process and save study material.' });
    }
  }
);

// PUT /api/materials/:id - Update material
materialsRouter.put('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const material = dbInstance.db.materials.find(
    (m) => m.id === req.params.id && (m.userId === userId || req.user!.role === 'admin')
  );

  if (!material) {
    return res.status(404).json({ error: 'Study material not found.' });
  }

  const { title, category, tags, content } = req.body;

  if (title) material.title = title.trim();
  if (category) material.category = category.trim();
  if (tags) {
    material.tags = Array.isArray(tags)
      ? tags
      : tags.split(',').map((t: string) => t.trim()).filter(Boolean);
  }
  if (content) {
    material.content = content.trim();
    material.wordCount = material.content.split(/\s+/).length;
    material.readingTimeMin = Math.max(1, Math.ceil(material.wordCount / 200));
  }

  material.updatedAt = new Date().toISOString();
  dbInstance.save();

  return res.json({ material, message: 'Material updated successfully.' });
});

// DELETE /api/materials/:id - Delete material
materialsRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const index = dbInstance.db.materials.findIndex(
    (m) => m.id === req.params.id && (m.userId === userId || req.user!.role === 'admin')
  );

  if (index === -1) {
    return res.status(404).json({ error: 'Study material not found.' });
  }

  dbInstance.db.materials.splice(index, 1);
  dbInstance.save();

  return res.json({ success: true, message: 'Material deleted successfully.' });
});

// GET /api/materials/:id/download - Download content as text file
materialsRouter.get('/:id/download', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const material = dbInstance.db.materials.find(
    (m) => m.id === req.params.id && (m.userId === userId || req.user!.role === 'admin')
  );

  if (!material) {
    return res.status(404).json({ error: 'Study material not found.' });
  }

  const safeFilename = (material.fileName || `${material.title}.txt`).replace(/[^a-zA-Z0-9._-]/g, '_');
  res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"`);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  return res.send(material.content);
});
