import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const summariesRouter = Router();

// GET /api/summaries
summariesRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const list = dbInstance.db.summaries
    .filter((s) => s.userId === userId || req.user!.role === 'admin')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  return res.json({ summaries: list });
});

// GET /api/summaries/:id
summariesRouter.get('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const summary = dbInstance.db.summaries.find(
    (s) => s.id === req.params.id && (s.userId === userId || req.user!.role === 'admin')
  );
  if (!summary) {
    return res.status(404).json({ error: 'Summary not found.' });
  }
  return res.json({ summary });
});

// DELETE /api/summaries/:id
summariesRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const index = dbInstance.db.summaries.findIndex(
    (s) => s.id === req.params.id && (s.userId === userId || req.user!.role === 'admin')
  );
  if (index === -1) {
    return res.status(404).json({ error: 'Summary not found.' });
  }
  dbInstance.db.summaries.splice(index, 1);
  dbInstance.save();
  return res.json({ success: true });
});
