import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const studyPlansRouter = Router();

// GET /api/studyplans
studyPlansRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const plans = dbInstance.db.studyPlans
    .filter((p) => p.userId === userId || req.user!.role === 'admin')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  return res.json({ studyPlans: plans });
});

// GET /api/studyplans/:id
studyPlansRouter.get('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const plan = dbInstance.db.studyPlans.find(
    (p) => p.id === req.params.id && (p.userId === userId || req.user!.role === 'admin')
  );
  if (!plan) {
    return res.status(404).json({ error: 'Study plan not found.' });
  }
  return res.json({ studyPlan: plan });
});

// PUT /api/studyplans/:id/tasks/:taskId - Toggle completion
studyPlansRouter.put('/:id/tasks/:taskId', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const plan = dbInstance.db.studyPlans.find(
    (p) => p.id === req.params.id && (p.userId === userId || req.user!.role === 'admin')
  );
  if (!plan) {
    return res.status(404).json({ error: 'Study plan not found.' });
  }

  const task = plan.tasks.find((t) => t.id === req.params.taskId);
  if (!task) {
    return res.status(404).json({ error: 'Task not found in study plan.' });
  }

  task.completed = !task.completed;
  dbInstance.save();

  return res.json({ success: true, task, studyPlan: plan });
});

// DELETE /api/studyplans/:id
studyPlansRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const index = dbInstance.db.studyPlans.findIndex(
    (p) => p.id === req.params.id && (p.userId === userId || req.user!.role === 'admin')
  );
  if (index === -1) {
    return res.status(404).json({ error: 'Study plan not found.' });
  }
  dbInstance.db.studyPlans.splice(index, 1);
  dbInstance.save();
  return res.json({ success: true });
});
