import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const progressRouter = Router();

// GET /api/progress/dashboard
progressRouter.get('/dashboard', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;

  const materials = dbInstance.db.materials.filter((m) => m.userId === userId);
  const summaries = dbInstance.db.summaries.filter((s) => s.userId === userId);
  const decks = dbInstance.db.flashcardDecks.filter((d) => d.userId === userId);
  const quizzes = dbInstance.db.quizzes.filter((q) => q.userId === userId);
  const attempts = dbInstance.db.quizAttempts.filter((a) => a.userId === userId);
  const studyPlans = dbInstance.db.studyPlans.filter((p) => p.userId === userId);

  // Flashcards mastery calculation
  let totalCards = 0;
  let masteredCards = 0;
  let learningCards = 0;
  let newCards = 0;

  decks.forEach((deck) => {
    deck.cards.forEach((card) => {
      totalCards++;
      if (card.masteryLevel === 'mastered') masteredCards++;
      else if (card.masteryLevel === 'learning') learningCards++;
      else newCards++;
    });
  });

  // Quiz analytics
  const totalAttempts = attempts.length;
  const avgQuizScore =
    totalAttempts > 0
      ? Math.round(attempts.reduce((acc, curr) => acc + curr.percentage, 0) / totalAttempts)
      : 0;
  const highestScore =
    totalAttempts > 0 ? Math.max(...attempts.map((a) => a.percentage)) : 0;

  // Study plan tasks
  let totalPlanTasks = 0;
  let completedPlanTasks = 0;
  studyPlans.forEach((plan) => {
    plan.tasks.forEach((t) => {
      totalPlanTasks++;
      if (t.completed) completedPlanTasks++;
    });
  });

  // Category distribution
  const categoryCounts: Record<string, number> = {};
  materials.forEach((m) => {
    categoryCounts[m.category] = (categoryCounts[m.category] || 0) + 1;
  });
  decks.forEach((d) => {
    categoryCounts[d.category] = (categoryCounts[d.category] || 0) + 1;
  });

  // Activity stream (recent 10 items)
  const activities = [
    ...materials.map((m) => ({
      id: m.id,
      type: 'material',
      title: `Uploaded "${m.title}"`,
      timestamp: m.uploadedAt,
      badge: m.category,
    })),
    ...summaries.map((s) => ({
      id: s.id,
      type: 'summary',
      title: `Generated Summary for "${s.title}"`,
      timestamp: s.createdAt,
      badge: s.mode,
    })),
    ...attempts.map((a) => ({
      id: a.id,
      type: 'quiz',
      title: `Scored ${a.percentage}% on "${a.quizTitle}"`,
      timestamp: a.completedAt,
      badge: `${a.score}/${a.totalQuestions} correct`,
    })),
  ]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 8);

  // Active study streak calculation (simulated 5 days or calculated)
  const studyStreakDays = 5;

  return res.json({
    metrics: {
      totalMaterials: materials.length,
      totalSummaries: summaries.length,
      totalFlashcardDecks: decks.length,
      totalCards,
      masteredCards,
      learningCards,
      newCards,
      cardMasteryPercentage: totalCards > 0 ? Math.round((masteredCards / totalCards) * 100) : 0,
      totalQuizzes: quizzes.length,
      totalQuizAttempts: totalAttempts,
      avgQuizScore,
      highestScore,
      totalPlanTasks,
      completedPlanTasks,
      planCompletionRate: totalPlanTasks > 0 ? Math.round((completedPlanTasks / totalPlanTasks) * 100) : 0,
      studyStreakDays,
      estimatedHoursSpent: Math.round(materials.reduce((acc, m) => acc + (m.readingTimeMin || 1), 0) / 30 + totalAttempts * 0.3),
    },
    categoryDistribution: Object.entries(categoryCounts).map(([name, count]) => ({ name, count })),
    recentActivities: activities,
    recentAttempts: attempts.slice(0, 5),
  });
});
