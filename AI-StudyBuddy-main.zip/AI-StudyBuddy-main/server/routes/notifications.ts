import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const notificationsRouter = Router();

// GET /api/notifications
notificationsRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const list = dbInstance.db.notifications
    .filter((n) => n.userId === userId || n.userId === 'all')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const unreadCount = list.filter((n) => !n.read).length;
  return res.json({ notifications: list, unreadCount });
});

// PUT /api/notifications/:id/read - Mark single as read
notificationsRouter.put('/:id/read', authenticateToken, (req: AuthRequest, res: Response) => {
  const notif = dbInstance.db.notifications.find((n) => n.id === req.params.id);
  if (notif) {
    notif.read = true;
    dbInstance.save();
  }
  return res.json({ success: true });
});

// PUT /api/notifications/read-all - Mark all as read
notificationsRouter.put('/read-all', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  dbInstance.db.notifications.forEach((n) => {
    if (n.userId === userId || n.userId === 'all') {
      n.read = true;
    }
  });
  dbInstance.save();
  return res.json({ success: true });
});

// DELETE /api/notifications/:id
notificationsRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const index = dbInstance.db.notifications.findIndex((n) => n.id === req.params.id);
  if (index !== -1) {
    dbInstance.db.notifications.splice(index, 1);
    dbInstance.save();
  }
  return res.json({ success: true });
});
