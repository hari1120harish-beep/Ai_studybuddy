import { Router, Response } from 'express';
import { dbInstance, QuizAttempt } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const quizzesRouter = Router();

// GET /api/quizzes
quizzesRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const quizzes = dbInstance.db.quizzes
    .filter((q) => q.userId === userId || req.user!.role === 'admin')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  return res.json({ quizzes });
});

// GET /api/quizzes/:id
quizzesRouter.get('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const quiz = dbInstance.db.quizzes.find(
    (q) => q.id === req.params.id && (q.userId === userId || req.user!.role === 'admin')
  );
  if (!quiz) {
    return res.status(404).json({ error: 'Quiz not found.' });
  }
  return res.json({ quiz });
});

// POST /api/quizzes/:id/attempt - Submit quiz answers
quizzesRouter.post('/:id/attempt', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const { userAnswers, timeSpentSeconds = 0 } = req.body; // userAnswers: { [questionId]: optionIndex }

  const quiz = dbInstance.db.quizzes.find(
    (q) => q.id === req.params.id && (q.userId === userId || req.user!.role === 'admin')
  );
  if (!quiz) {
    return res.status(404).json({ error: 'Quiz not found.' });
  }

  let correctCount = 0;
  quiz.questions.forEach((q) => {
    if (userAnswers[q.id] === q.correctAnswer) {
      correctCount++;
    }
  });

  const percentage = Math.round((correctCount / quiz.questions.length) * 100);

  const attempt: QuizAttempt = {
    id: `att_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    quizId: quiz.id,
    quizTitle: quiz.title,
    score: correctCount,
    totalQuestions: quiz.questions.length,
    percentage,
    userAnswers: userAnswers || {},
    timeSpentSeconds,
    completedAt: new Date().toISOString(),
  };

  dbInstance.db.quizAttempts.unshift(attempt);

  // Send congratulatory or encouragement notification
  dbInstance.db.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId,
    title: percentage >= 80 ? '🌟 Outstanding Quiz Score!' : 'Quiz Completed',
    message: `You scored ${percentage}% (${correctCount}/${quiz.questions.length}) on "${quiz.title}".`,
    type: percentage >= 80 ? 'success' : 'info',
    read: false,
    createdAt: new Date().toISOString(),
  });

  dbInstance.save();

  return res.status(201).json({ attempt, quiz });
});

// GET /api/quizzes/attempts/history
quizzesRouter.get('/attempts/history', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const attempts = dbInstance.db.quizAttempts
    .filter((a) => a.userId === userId || req.user!.role === 'admin')
    .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  return res.json({ attempts });
});

// DELETE /api/quizzes/:id
quizzesRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const index = dbInstance.db.quizzes.findIndex(
    (q) => q.id === req.params.id && (q.userId === userId || req.user!.role === 'admin')
  );
  if (index === -1) {
    return res.status(404).json({ error: 'Quiz not found.' });
  }
  dbInstance.db.quizzes.splice(index, 1);
  dbInstance.save();
  return res.json({ success: true });
});
