import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

export const flashcardsRouter = Router();

// GET /api/flashcards - Get decks
flashcardsRouter.get('/', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const decks = dbInstance.db.flashcardDecks
    .filter((d) => d.userId === userId || req.user!.role === 'admin')
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  return res.json({ decks });
});

// GET /api/flashcards/:id - Single deck
flashcardsRouter.get('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const deck = dbInstance.db.flashcardDecks.find(
    (d) => d.id === req.params.id && (d.userId === userId || req.user!.role === 'admin')
  );
  if (!deck) {
    return res.status(404).json({ error: 'Deck not found.' });
  }
  return res.json({ deck });
});

// POST /api/flashcards/:deckId/review - Update card mastery (spaced repetition review)
flashcardsRouter.post('/:deckId/review', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const { cardId, rating } = req.body; // rating: 'easy' | 'medium' | 'hard'

  const deck = dbInstance.db.flashcardDecks.find(
    (d) => d.id === req.params.deckId && (d.userId === userId || req.user!.role === 'admin')
  );
  if (!deck) {
    return res.status(404).json({ error: 'Deck not found.' });
  }

  const card = deck.cards.find((c) => c.id === cardId);
  if (!card) {
    return res.status(404).json({ error: 'Card not found in deck.' });
  }

  card.reviewCount = (card.reviewCount || 0) + 1;
  card.lastReviewed = new Date().toISOString();

  if (rating === 'easy') {
    card.masteryLevel = 'mastered';
  } else if (rating === 'medium') {
    card.masteryLevel = 'learning';
  } else {
    card.masteryLevel = 'new';
  }

  deck.updatedAt = new Date().toISOString();
  dbInstance.save();

  return res.json({ success: true, card, deck });
});

// DELETE /api/flashcards/:id
flashcardsRouter.delete('/:id', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const index = dbInstance.db.flashcardDecks.findIndex(
    (d) => d.id === req.params.id && (d.userId === userId || req.user!.role === 'admin')
  );
  if (index === -1) {
    return res.status(404).json({ error: 'Deck not found.' });
  }
  dbInstance.db.flashcardDecks.splice(index, 1);
  dbInstance.save();
  return res.json({ success: true });
});
