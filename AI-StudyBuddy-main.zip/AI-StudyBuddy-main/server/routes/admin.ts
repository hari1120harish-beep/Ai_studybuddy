import { Router, Response } from 'express';
import { dbInstance } from '../db.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

export const adminRouter = Router();

// Protect all admin routes
adminRouter.use(authenticateToken);
adminRouter.use(requireAdmin);

// GET /api/admin/users
adminRouter.get('/users', (req: AuthRequest, res: Response) => {
  const users = dbInstance.db.users.map(({ passwordHash, ...safeUser }) => safeUser);
  return res.json({ users });
});

// PUT /api/admin/users/:id/role
adminRouter.put('/users/:id/role', (req: AuthRequest, res: Response) => {
  const { role } = req.body;
  if (role !== 'student' && role !== 'admin') {
    return res.status(400).json({ error: 'Role must be student or admin.' });
  }

  const user = dbInstance.db.users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  user.role = role;
  dbInstance.save();

  const { passwordHash, ...safeUser } = user;
  return res.json({ user: safeUser, message: 'User role updated.' });
});

// PUT /api/admin/users/:id/status
adminRouter.put('/users/:id/status', (req: AuthRequest, res: Response) => {
  const { status } = req.body;
  if (status !== 'active' && status !== 'suspended') {
    return res.status(400).json({ error: 'Status must be active or suspended.' });
  }

  const user = dbInstance.db.users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  user.status = status;
  dbInstance.save();

  const { passwordHash, ...safeUser } = user;
  return res.json({ user: safeUser, message: `User status changed to ${status}.` });
});

// DELETE /api/admin/users/:id
adminRouter.delete('/users/:id', (req: AuthRequest, res: Response) => {
  if (req.user?.id === req.params.id) {
    return res.status(400).json({ error: 'You cannot delete your own admin account.' });
  }

  const index = dbInstance.db.users.findIndex((u) => u.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'User not found.' });
  }

  dbInstance.db.users.splice(index, 1);
  dbInstance.save();

  return res.json({ success: true, message: 'User deleted.' });
});

// GET /api/admin/analytics - Platform wide analytics & AI usage
adminRouter.get('/analytics', (req: AuthRequest, res: Response) => {
  const totalUsers = dbInstance.db.users.length;
  const activeUsers = dbInstance.db.users.filter((u) => u.status === 'active').length;
  const totalMaterials = dbInstance.db.materials.length;
  const totalSummaries = dbInstance.db.summaries.length;
  const totalFlashcardDecks = dbInstance.db.flashcardDecks.length;
  const totalQuizzes = dbInstance.db.quizzes.length;
  const totalAttempts = dbInstance.db.quizAttempts.length;

  const totalTokens = dbInstance.db.aiUsageLogs.reduce(
    (acc, log) => acc + (log.promptTokensEstimate || 0),
    0
  );

  // AI Usage action breakdown
  const actionBreakdown: Record<string, number> = {};
  dbInstance.db.aiUsageLogs.forEach((l) => {
    actionBreakdown[l.action] = (actionBreakdown[l.action] || 0) + 1;
  });

  return res.json({
    metrics: {
      totalUsers,
      activeUsers,
      totalMaterials,
      totalSummaries,
      totalFlashcardDecks,
      totalQuizzes,
      totalAttempts,
      totalTokens,
      aiRequestsCount: dbInstance.db.aiUsageLogs.length,
    },
    actionBreakdown: Object.entries(actionBreakdown).map(([action, count]) => ({ action, count })),
    recentLogs: dbInstance.db.aiUsageLogs.slice(0, 15),
    materialsOverview: dbInstance.db.materials.map((m) => {
      const owner = dbInstance.db.users.find((u) => u.id === m.userId);
      return {
        id: m.id,
        title: m.title,
        category: m.category,
        fileType: m.fileType,
        wordCount: m.wordCount,
        ownerName: owner ? owner.name : 'Unknown',
        uploadedAt: m.uploadedAt,
      };
    }),
  });
});

// POST /api/admin/broadcast - Send platform notification to all students
adminRouter.post('/broadcast', (req: AuthRequest, res: Response) => {
  const { title, message, type = 'info' } = req.body;

  if (!title || !message) {
    return res.status(400).json({ error: 'Title and message are required.' });
  }

  const notification = {
    id: `notif_${Date.now()}`,
    userId: 'all',
    title: title.trim(),
    message: message.trim(),
    type: type as any,
    read: false,
    createdAt: new Date().toISOString(),
  };

  dbInstance.db.notifications.unshift(notification);
  dbInstance.save();

  return res.status(201).json({ success: true, notification });
});
