import { Router, Response } from 'express';
import { dbInstance, Summary, FlashcardDeck, Quiz, StudyPlan } from '../db.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';
import {
  generateSummaryAI,
  generateFlashcardsAI,
  generateQuizAI,
  generateStudyPlanAI,
  askStudyBuddyAI,
} from '../gemini.js';

export const aiRouter = Router();

// POST /api/ai/summarize
aiRouter.post('/summarize', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = req.user!.name;
    const { materialId, title, category = 'General', mode = 'comprehensive', content } = req.body;

    let targetContent = content || '';
    let targetTitle = title || 'Study Summary';
    let targetCategory = category;

    if (materialId) {
      const mat = dbInstance.db.materials.find((m) => m.id === materialId && (m.userId === userId || req.user!.role === 'admin'));
      if (mat) {
        targetContent = mat.content;
        targetTitle = title || mat.title;
        targetCategory = mat.category;
      }
    }

    if (!targetContent || !targetContent.trim()) {
      return res.status(400).json({ error: 'Content is required to generate a summary.' });
    }

    const aiResult = await generateSummaryAI({
      title: targetTitle,
      category: targetCategory,
      mode,
      content: targetContent,
      userId,
      userName,
    });

    const newSummary: Summary = {
      id: `sum_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      materialId,
      title: `${targetTitle} - Summary`,
      category: targetCategory,
      mode,
      executiveSummary: aiResult.executiveSummary,
      keyConcepts: aiResult.keyConcepts,
      takeaways: aiResult.takeaways,
      mindmapOutline: aiResult.mindmapOutline,
      suggestedQuestions: aiResult.suggestedQuestions,
      createdAt: new Date().toISOString(),
    };

    dbInstance.db.summaries.unshift(newSummary);
    dbInstance.save();

    return res.status(201).json({ summary: newSummary });
  } catch (error) {
    console.error('AI summarize endpoint error:', error);
    return res.status(500).json({ error: 'Failed to generate summary with AI.' });
  }
});

// POST /api/ai/flashcards
aiRouter.post('/flashcards', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = req.user!.name;
    const { materialId, topic, count = 8, content, deckTitle } = req.body;

    let targetContent = content || '';
    let targetTopic = topic || 'Study Material';

    if (materialId) {
      const mat = dbInstance.db.materials.find((m) => m.id === materialId && (m.userId === userId || req.user!.role === 'admin'));
      if (mat) {
        targetContent = mat.content;
        targetTopic = topic || mat.title;
      }
    }

    if (!targetContent || !targetContent.trim()) {
      return res.status(400).json({ error: 'Content is required to generate flashcards.' });
    }

    const cards = await generateFlashcardsAI({
      topic: targetTopic,
      content: targetContent,
      count: Number(count) || 8,
      userId,
      userName,
    });

    const newDeck: FlashcardDeck = {
      id: `deck_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      materialId,
      title: deckTitle || `${targetTopic} Flashcards`,
      description: `Active recall deck for ${targetTopic}. Generated with Gemini AI.`,
      category: req.body.category || 'General',
      cards,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    dbInstance.db.flashcardDecks.unshift(newDeck);
    dbInstance.save();

    return res.status(201).json({ deck: newDeck });
  } catch (error) {
    console.error('AI flashcards endpoint error:', error);
    return res.status(500).json({ error: 'Failed to generate flashcards.' });
  }
});

// POST /api/ai/quiz
aiRouter.post('/quiz', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = req.user!.name;
    const { materialId, topic, numQuestions = 5, difficulty = 'medium', content, timeLimitMinutes = 10 } = req.body;

    let targetContent = content || '';
    let targetTopic = topic || 'Study Quiz';

    if (materialId) {
      const mat = dbInstance.db.materials.find((m) => m.id === materialId && (m.userId === userId || req.user!.role === 'admin'));
      if (mat) {
        targetContent = mat.content;
        targetTopic = topic || mat.title;
      }
    }

    if (!targetContent || !targetContent.trim()) {
      return res.status(400).json({ error: 'Content is required to generate a quiz.' });
    }

    const quizData = await generateQuizAI({
      topic: targetTopic,
      content: targetContent,
      numQuestions: Number(numQuestions) || 5,
      difficulty,
      userId,
      userName,
    });

    const newQuiz: Quiz = {
      id: `quiz_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      materialId,
      title: quizData.title || `${targetTopic} Quiz`,
      topic: targetTopic,
      questions: quizData.questions,
      timeLimitMinutes: Number(timeLimitMinutes) || 10,
      createdAt: new Date().toISOString(),
    };

    dbInstance.db.quizzes.unshift(newQuiz);
    dbInstance.save();

    return res.status(201).json({ quiz: newQuiz });
  } catch (error) {
    console.error('AI quiz endpoint error:', error);
    return res.status(500).json({ error: 'Failed to generate practice quiz.' });
  }
});

// POST /api/ai/studyplan
aiRouter.post('/studyplan', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = req.user!.name;
    const { title, goal, examDate, days = 7, dailyHours = 3, materialIds = [] } = req.body;

    if (!goal || !goal.trim()) {
      return res.status(400).json({ error: 'Learning goal or target exam is required.' });
    }

    // Aggregate context from selected materials if provided
    let materialsContext = '';
    if (Array.isArray(materialIds) && materialIds.length > 0) {
      const selectedMaterials = dbInstance.db.materials.filter(
        (m) => materialIds.includes(m.id) && (m.userId === userId || req.user!.role === 'admin')
      );
      materialsContext = selectedMaterials.map((m) => `[Subject: ${m.title}]: ${m.content.slice(0, 1500)}`).join('\n\n');
    }

    const tasks = await generateStudyPlanAI({
      title: title || `${days}-Day Study Roadmap`,
      goal,
      examDate,
      days: Number(days) || 7,
      dailyHours: Number(dailyHours) || 3,
      materialsContext,
      userId,
      userName,
    });

    const newPlan: StudyPlan = {
      id: `plan_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      title: title || `${days}-Day Study Sprint: ${goal}`,
      goal,
      examDate,
      totalDays: Number(days) || 7,
      dailyHours: Number(dailyHours) || 3,
      tasks,
      createdAt: new Date().toISOString(),
    };

    dbInstance.db.studyPlans.unshift(newPlan);
    dbInstance.save();

    return res.status(201).json({ studyPlan: newPlan });
  } catch (error) {
    console.error('AI study plan endpoint error:', error);
    return res.status(500).json({ error: 'Failed to generate study plan.' });
  }
});

// POST /api/ai/ask - Interactive AI tutor
aiRouter.post('/ask', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = req.user!.name;
    const { question, materialId, mode = 'explain', conversationHistory = [] } = req.body;

    if (!question || !question.trim()) {
      return res.status(400).json({ error: 'Question is required.' });
    }

    let materialsContext = '';
    if (materialId) {
      const mat = dbInstance.db.materials.find((m) => m.id === materialId && (m.userId === userId || req.user!.role === 'admin'));
      if (mat) {
        materialsContext = `Document "${mat.title}" (${mat.category}):\n${mat.content}`;
      }
    } else {
      // Gather top 3 user materials for general context
      const userMats = dbInstance.db.materials.filter((m) => m.userId === userId).slice(0, 3);
      materialsContext = userMats.map((m) => `Title: ${m.title}\nExcerpt: ${m.content.slice(0, 800)}`).join('\n\n');
    }

    const result = await askStudyBuddyAI({
      question,
      materialsContext,
      conversationHistory,
      mode,
      userId,
      userName,
    });

    return res.json(result);
  } catch (error) {
    console.error('AI ask endpoint error:', error);
    return res.status(500).json({ error: 'Failed to generate tutor response.' });
  }
});

// POST /api/ai/analyze - Content complexity & readability analysis
aiRouter.post('/analyze', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const { content } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Content is required.' });
    }

    const words = content.trim().split(/\s+/);
    const wordCount = words.length;
    const charCount = content.length;
    const sentenceCount = (content.match(/[.!?]+/g) || []).length || 1;
    const avgWordsPerSentence = Math.round((wordCount / sentenceCount) * 10) / 10;
    const estReadingTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));

    // Frequency analysis for key terms
    const stopWords = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'have', 'were', 'which', 'about', 'more', 'into', 'their']);
    const wordFreq: Record<string, number> = {};
    for (const w of words) {
      const clean = w.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (clean.length > 3 && !stopWords.has(clean)) {
        wordFreq[clean] = (wordFreq[clean] || 0) + 1;
      }
    }
    const topKeywords = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([word, freq]) => ({ word, count: freq }));

    return res.json({
      wordCount,
      charCount,
      sentenceCount,
      avgWordsPerSentence,
      estReadingTimeMinutes,
      difficultyRating: avgWordsPerSentence > 22 ? 'Advanced / Academic' : avgWordsPerSentence > 14 ? 'Intermediate' : 'Introductory',
      topKeywords,
    });
  } catch (error) {
    return res.status(500).json({ error: 'Content analysis failed.' });
  }
});
