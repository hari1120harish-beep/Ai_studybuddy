import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { dbInstance, User } from '../db.js';
import { authenticateToken, AuthRequest, JWT_SECRET } from '../middleware/auth.js';

export const authRouter = Router();

// POST /api/auth/register
authRouter.post('/register', async (req, res) => {
  try {
    const { name, email, password, role = 'student', targetExam, learningGoal, studyHoursPerDay } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    const emailTrimmed = email.trim().toLowerCase();
    const existing = dbInstance.db.users.find((u) => u.email.toLowerCase() === emailTrimmed);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser: User = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: emailTrimmed,
      passwordHash,
      role: role === 'admin' ? 'admin' : 'student',
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`,
      targetExam: targetExam || 'General Academics',
      learningGoal: learningGoal || 'Improve retention & study efficiently',
      studyHoursPerDay: studyHoursPerDay ? Number(studyHoursPerDay) : 2,
      createdAt: new Date().toISOString(),
      status: 'active',
    };

    dbInstance.db.users.push(newUser);

    // Initial welcome notification
    dbInstance.db.notifications.unshift({
      id: `notif_${Date.now()}`,
      userId: newUser.id,
      title: 'Welcome to AI StudyBuddy!',
      message: 'Upload your first study document or notes to generate summaries, flashcards, and quizzes.',
      type: 'info',
      read: false,
      createdAt: new Date().toISOString(),
    });

    dbInstance.save();

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = newUser;
    return res.status(201).json({ token, user: safeUser });
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// POST /api/auth/login
authRouter.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const emailTrimmed = email.trim().toLowerCase();
    const user = dbInstance.db.users.find((u) => u.email.toLowerCase() === emailTrimmed);

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    if (user.status === 'suspended') {
      return res.status(403).json({ error: 'This account has been suspended by an administrator.' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = user;
    return res.json({ token, user: safeUser });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Internal server error during sign in.' });
  }
});

// GET /api/auth/me
authRouter.get('/me', authenticateToken, (req: AuthRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  const { passwordHash: _, ...safeUser } = req.user;
  return res.json({ user: safeUser });
});

// PUT /api/auth/profile
authRouter.put('/profile', authenticateToken, (req: AuthRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });

  const { name, targetExam, learningGoal, studyHoursPerDay, avatar } = req.body;
  const user = dbInstance.db.users.find((u) => u.id === req.user!.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (name) user.name = name.trim();
  if (targetExam !== undefined) user.targetExam = targetExam;
  if (learningGoal !== undefined) user.learningGoal = learningGoal;
  if (studyHoursPerDay !== undefined) user.studyHoursPerDay = Number(studyHoursPerDay);
  if (avatar) user.avatar = avatar;

  dbInstance.save();
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ user: safeUser, message: 'Profile updated successfully.' });
});
